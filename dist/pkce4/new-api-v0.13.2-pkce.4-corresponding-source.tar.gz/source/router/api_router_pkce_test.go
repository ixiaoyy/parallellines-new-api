package router

import (
	"testing"

	"github.com/gin-gonic/gin"
)

func TestCustomPKCERouteRegistration(t *testing.T) {
	gin.SetMode(gin.TestMode)
	engine := gin.New()
	SetApiRouter(engine) // Also catches conflicts with existing static OAuth routes.
	found := false
	for _, route := range engine.Routes() {
		if route.Method == "POST" && route.Path == "/api/oauth/:provider/start" {
			found = true
		}
	}
	if !found {
		t.Fatal("PKCE authorization route is missing")
	}
}
