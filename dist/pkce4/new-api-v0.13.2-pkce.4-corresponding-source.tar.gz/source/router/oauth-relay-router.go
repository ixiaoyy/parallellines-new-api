package router

import (
	"github.com/QuantumNous/new-api/controller"
	"github.com/QuantumNous/new-api/middleware"
	"github.com/QuantumNous/new-api/types"
	"github.com/gin-gonic/gin"
)

func setChatOAuthRelayRouter(router *gin.Engine) {
	group := router.Group("/oauth-relay/v1", middleware.RouteTag("relay"))
	group.GET("/models", middleware.ChatOAuthRelay("/v1/models"), middleware.TokenAuth(), controller.ListChatOAuthRelayModels)
	for _, route := range []struct {
		path   string
		format types.RelayFormat
	}{
		{"/chat/completions", types.RelayFormatOpenAI},
		{"/responses", types.RelayFormatOpenAIResponses},
	} {
		format := route.format
		group.POST(route.path,
			middleware.SystemPerformanceCheck(),
			middleware.ChatOAuthRelay("/v1"+route.path), middleware.TokenAuth(),
			middleware.ChatOAuthRelayModelLimit(), middleware.ModelRequestRateLimit(), middleware.Distribute(),
			func(c *gin.Context) { controller.Relay(c, format) },
		)
	}
}
