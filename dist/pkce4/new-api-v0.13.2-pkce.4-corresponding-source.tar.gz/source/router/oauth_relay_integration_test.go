package router

import (
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/i18n"
	"github.com/QuantumNous/new-api/model"
	"github.com/QuantumNous/new-api/setting/ratio_setting"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm/logger"
)

type oauthRelayIntegrationTransport func(*http.Request) (*http.Response, error)

func (f oauthRelayIntegrationTransport) RoundTrip(r *http.Request) (*http.Response, error) {
	return f(r)
}

// All identities, tokens, quota, channels and prices in this test are synthetic.
// The catch-all transport rejects every non-UserInfo request without opening a socket.
func TestChatOAuthRelayIntegration(t *testing.T) {
	gin.SetMode(gin.TestMode)
	if err := i18n.Init(); err != nil {
		t.Fatal(err)
	}
	oldDB, oldPath, oldMaster := model.DB, common.SQLitePath, common.IsMasterNode
	oldRedis, oldBatch, oldMemory := common.RedisEnabled, common.BatchUpdateEnabled, common.MemoryCacheEnabled
	oldCount, oldTransport := constant.CountToken, http.DefaultTransport
	oldPrices := ratio_setting.ModelPrice2JSONString()
	t.Setenv("SQL_DSN", "local")
	t.Setenv("SQL_MAX_OPEN_CONNS", "1")
	t.Setenv("CHAT_OAUTH_RELAY_ENABLED", "true")
	common.SQLitePath = "file:oauth-relay-router-integration?mode=memory&cache=shared"
	common.IsMasterNode, common.RedisEnabled, common.BatchUpdateEnabled, common.MemoryCacheEnabled = false, false, false, false
	constant.CountToken = false // No tokenizer downloads; price fixtures are per-request, not production rates.
	if err := model.InitDB(); err != nil {
		t.Fatal(err)
	}
	model.DB.Logger = logger.Default.LogMode(logger.Silent)
	t.Cleanup(func() {
		sqlDB, _ := model.DB.DB()
		_ = sqlDB.Close()
		model.DB, common.SQLitePath, common.IsMasterNode = oldDB, oldPath, oldMaster
		common.RedisEnabled, common.BatchUpdateEnabled, common.MemoryCacheEnabled = oldRedis, oldBatch, oldMemory
		constant.CountToken, http.DefaultTransport = oldCount, oldTransport
		_ = ratio_setting.UpdateModelPriceByJSONString(oldPrices)
	})
	if err := model.DB.AutoMigrate(&model.User{}, &model.Token{}, &model.CustomOAuthProvider{}, &model.UserOAuthBinding{}, &model.Channel{}, &model.Ability{}); err != nil {
		t.Fatal(err)
	}
	provider := model.CustomOAuthProvider{Id: 1, Name: "fixture", Slug: "pingxingxian", Enabled: true, UserIdField: "sub", UserInfoEndpoint: model.OAuthRelayUserInfoURL}
	if err := model.DB.Create(&provider).Error; err != nil {
		t.Fatal(err)
	}
	for i, sub := range []string{"fixture-zero", "fixture-other"} {
		group := "default"
		if i == 1 {
			group = "fixture-group"
		}
		user := model.User{Id: 501 + i, Username: sub, AffCode: sub, Role: common.RoleCommonUser, Status: common.UserStatusEnabled, Group: group, Quota: 0, Setting: `{"billing_preference":"wallet_only"}`}
		if err := model.DB.Create(&user).Error; err != nil {
			t.Fatal(err)
		}
		if err := model.DB.Create(&model.UserOAuthBinding{UserId: user.Id, ProviderId: 1, ProviderUserId: sub}).Error; err != nil {
			t.Fatal(err)
		}
	}
	upstream := "https://synthetic-upstream.test"
	channel := model.Channel{Id: 701, Type: constant.ChannelTypeOpenAI, Name: "synthetic-only", Key: "synthetic-channel-key", Status: common.ChannelStatusEnabled, BaseURL: &upstream, Models: model.OAuthRelayModelLimits, Group: "default,fixture-group"}
	if err := model.DB.Create(&channel).Error; err != nil {
		t.Fatal(err)
	}
	for _, name := range append(strings.Split(model.OAuthRelayModelLimits, ","), "unapproved-model") {
		if err := model.DB.Create(&model.Ability{Group: "default", Model: name, ChannelId: channel.Id, Enabled: true}).Error; err != nil {
			t.Fatal(err)
		}
	}
	for _, ability := range []model.Ability{
		{Group: "fixture-group", Model: "gpt-6.1-terra", ChannelId: channel.Id, Enabled: true},
		{Group: "fixture-group", Model: "gpt-6.1-sol", ChannelId: channel.Id, Enabled: false},
	} {
		if err := model.DB.Create(&ability).Error; err != nil {
			t.Fatal(err)
		}
	}
	if err := ratio_setting.UpdateModelPriceByJSONString(`{"gpt-6-luna":0.001,"gpt-6.1-terra":0.001,"gpt-6.1-sol":0.001}`); err != nil {
		t.Fatal(err)
	}
	userinfoCalls, forbiddenCalls := 0, 0
	http.DefaultTransport = oauthRelayIntegrationTransport(func(r *http.Request) (*http.Response, error) {
		if r.URL.String() != model.OAuthRelayUserInfoURL || r.Method != http.MethodGet {
			forbiddenCalls++
			return nil, fmt.Errorf("all non-UserInfo network requests are blocked by the fixture")
		}
		userinfoCalls++
		sub := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer oauth-")
		if sub != "fixture-zero" && sub != "fixture-other" {
			return &http.Response{StatusCode: 401, Body: http.NoBody, Header: make(http.Header), Request: r}, nil
		}
		body, err := common.Marshal(map[string]any{"iss": "https://pingxingxian.space/auth/oidc", "aud": "parallellines-openwebui", "sub": sub, "pl_binding": "synthetic-binding", "pl_auth_exp": time.Now().Unix() + 300})
		if err != nil {
			return nil, err
		}
		return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": {"application/json"}}, Body: io.NopCloser(strings.NewReader(string(body))), Request: r}, nil
	})
	engine := gin.New()
	SetRelayRouter(engine)
	request := func(method, path, identity, body string) *httptest.ResponseRecorder {
		t.Helper()
		req := httptest.NewRequest(method, path, strings.NewReader(body))
		if identity != "" {
			req.Header.Set("Authorization", "Bearer oauth-"+identity)
		}
		if body != "" {
			req.Header.Set("Content-Type", "application/json")
		}
		res := httptest.NewRecorder()
		engine.ServeHTTP(res, req)
		return res
	}
	t.Run("exact route surface", func(t *testing.T) {
		actual := map[string]bool{}
		for _, route := range engine.Routes() {
			if strings.HasPrefix(route.Path, "/oauth-relay/") {
				actual[route.Method+" "+route.Path] = true
			}
		}
		want := map[string]bool{"GET /oauth-relay/v1/models": true, "POST /oauth-relay/v1/chat/completions": true, "POST /oauth-relay/v1/responses": true}
		if !reflect.DeepEqual(actual, want) {
			t.Fatalf("unexpected adapter route surface: %v", actual)
		}
	})
	t.Run("zero quota models respect group and allowlist", func(t *testing.T) {
		for _, tc := range []struct {
			sub string
			ids []string
		}{
			{"fixture-zero", strings.Split(model.OAuthRelayModelLimits, ",")},
			{"fixture-other", []string{"gpt-6.1-terra"}},
		} {
			res := request("GET", "/oauth-relay/v1/models", tc.sub, "")
			if res.Code != 200 {
				t.Fatalf("models HTTP %d: %s", res.Code, res.Body.String())
			}
			var body struct {
				Data []struct {
					ID string `json:"id"`
				} `json:"data"`
			}
			if err := common.Unmarshal(res.Body.Bytes(), &body); err != nil {
				t.Fatal(err)
			}
			var ids []string
			for _, entry := range body.Data {
				ids = append(ids, entry.ID)
			}
			if !reflect.DeepEqual(ids, tc.ids) {
				t.Fatalf("models escaped group/allowlist: %v", ids)
			}
			if res.Header().Get("Cache-Control") != "no-store" {
				t.Fatal("identity response is cacheable")
			}
		}
	})
	t.Run("both paid routes reject unsupported models before upstream", func(t *testing.T) {
		for _, path := range []string{"/chat/completions", "/responses"} {
			res := request("POST", "/oauth-relay/v1"+path, "fixture-zero", `{"model":"unapproved-model"}`)
			if res.Code != 403 {
				t.Fatalf("unsupported model HTTP %d", res.Code)
			}
		}
	})
	t.Run("native relay billing rejects zero quota for both protocols", func(t *testing.T) {
		for _, tc := range []struct{ path, body string }{
			{"/chat/completions", `{"model":"gpt-6-luna","messages":[{"role":"user","content":"synthetic"}]}`},
			{"/responses", `{"model":"gpt-6-luna","input":"synthetic"}`},
		} {
			res := request("POST", "/oauth-relay/v1"+tc.path, "fixture-zero", tc.body)
			if res.Code != 403 || !strings.Contains(res.Body.String(), "insufficient_user_quota") {
				t.Fatalf("native quota rejection missing: HTTP %d %s", res.Code, res.Body.String())
			}
		}
	})
	t.Run("anonymous and invalid identities rejected", func(t *testing.T) {
		for _, identity := range []string{"", "untrusted"} {
			if res := request("GET", "/oauth-relay/v1/models", identity, ""); res.Code != 401 {
				t.Fatalf("untrusted identity HTTP %d", res.Code)
			}
		}
	})
	var tokens []model.Token
	if err := model.DB.Where("internal_purpose = ?", model.OAuthRelayTokenPurpose).Order("user_id").Find(&tokens).Error; err != nil {
		t.Fatal(err)
	}
	if len(tokens) != 2 || tokens[0].UserId != 501 || tokens[1].UserId != 502 || tokens[0].Key == tokens[1].Key {
		t.Fatal("router identities did not receive separate native token owners")
	}
	for _, token := range tokens {
		res := request("GET", "/oauth-relay/v1/models", "fixture-zero", "")
		if strings.Contains(res.Body.String(), token.Key) {
			t.Fatal("internal credential leaked in client response")
		}
		var user model.User
		if err := model.DB.First(&user, token.UserId).Error; err != nil || user.Quota != 0 || user.UsedQuota != 0 {
			t.Fatal("read/denied request changed quota")
		}
	}
	if userinfoCalls == 0 || forbiddenCalls != 0 {
		t.Fatalf("unexpected request counts: UserInfo=%d blocked-other=%d", userinfoCalls, forbiddenCalls)
	}
}
