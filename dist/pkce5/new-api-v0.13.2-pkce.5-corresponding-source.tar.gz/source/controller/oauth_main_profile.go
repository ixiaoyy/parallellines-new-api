package controller

import (
	"errors"
	"strings"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	"github.com/QuantumNous/new-api/oauth"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
	gormlogger "gorm.io/gorm/logger"
)

type MainProfileConflictError struct{}

func (*MainProfileConflictError) Error() string {
	return "Main account profile conflicts with an existing account. Contact an administrator."
}

var errMainProfileUnavailable = errors.New("Main account profile could not be synchronized. Please retry or contact an administrator.")

func mainProfileCollision(tx *gorm.DB, userID int, profile *oauth.OAuthUser) error {
	var count int64
	if err := tx.Unscoped().Model(&model.User{}).Where("id <> ? AND (username = ? OR LOWER(email) = ?)",
		userID, profile.Username, strings.ToLower(profile.Email)).Count(&count).Error; err != nil {
		return errMainProfileUnavailable
	}
	if count != 0 {
		return &MainProfileConflictError{}
	}
	return nil
}

// The stable provider+subject binding is the sole account lookup key. Neither
// username nor email may merge accounts, change role, or rewrite a password.
func findOrCreateMainProfileUser(db *gorm.DB, provider *oauth.GenericOAuthProvider,
	profile *oauth.OAuthUser, inviterID int) (*model.User, bool, error) {
	if err := provider.ValidateMainProfileConfiguration(); err != nil {
		return nil, false, err
	}
	if err := oauth.ValidateMainProfile(profile); err != nil {
		return nil, false, err
	}
	var user model.User
	created := false
	// Database errors can include query parameters. Never log private profile values.
	err := db.Session(&gorm.Session{Logger: db.Logger.LogMode(gormlogger.Silent)}).Transaction(func(tx *gorm.DB) error {
		var liveProvider model.CustomOAuthProvider
		// Serializes Main-profile writers on databases with row locks. SQLite's
		// write serialization rejects a racing write, which fails the login closed.
		if err := tx.Clauses(clause.Locking{Strength: "UPDATE"}).First(&liveProvider, provider.GetProviderId()).Error; err != nil {
			return errMainProfileUnavailable
		}
		if err := oauth.NewGenericOAuthProvider(&liveProvider).ValidateMainProfileConfiguration(); err != nil {
			return err
		}
		var binding model.UserOAuthBinding
		err := tx.Clauses(clause.Locking{Strength: "UPDATE"}).Where("provider_id = ? AND provider_user_id = ?",
			provider.GetProviderId(), profile.ProviderUserID).First(&binding).Error
		if err == nil {
			if tx.Clauses(clause.Locking{Strength: "UPDATE"}).First(&user, binding.UserId).Error != nil ||
				user.Status != common.UserStatusEnabled {
				return errMainProfileUnavailable
			}
			if err := mainProfileCollision(tx, user.Id, profile); err != nil {
				return err
			}
			if err := tx.Model(&user).Updates(map[string]any{"username": profile.Username,
				"display_name": profile.DisplayName, "email": profile.Email}).Error; err != nil {
				return errMainProfileUnavailable
			}
			user.Username, user.DisplayName, user.Email = profile.Username, profile.DisplayName, profile.Email
			return nil
		}
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			return errMainProfileUnavailable
		}
		if !common.RegisterEnabled {
			return &OAuthRegistrationDisabledError{}
		}
		if err := mainProfileCollision(tx, 0, profile); err != nil {
			return err
		}
		user = model.User{Username: profile.Username, DisplayName: profile.DisplayName, Email: profile.Email,
			Role: common.RoleCommonUser, Status: common.UserStatusEnabled}
		if user.InsertWithTx(tx, inviterID) != nil {
			return errMainProfileUnavailable
		}
		binding = model.UserOAuthBinding{UserId: user.Id, ProviderId: provider.GetProviderId(), ProviderUserId: profile.ProviderUserID}
		if model.CreateUserOAuthBindingWithTx(tx, &binding) != nil {
			return errMainProfileUnavailable
		}
		created = true
		return nil
	})
	if err != nil {
		// Commit/driver errors can contain private SQL values; preserve only our
		// explicitly safe errors, never forward the raw database message.
		var conflict *MainProfileConflictError
		var registration *OAuthRegistrationDisabledError
		if errors.As(err, &conflict) || errors.As(err, &registration) ||
			errors.Is(err, oauth.ErrMainProfileConfig) || errors.Is(err, errMainProfileUnavailable) {
			return nil, false, err
		}
		return nil, false, errMainProfileUnavailable
	}
	if err := model.InvalidateUserCache(user.Id); err != nil {
		return nil, false, errMainProfileUnavailable
	}
	return &user, created, nil
}
