package controller

import (
	"errors"
	"path/filepath"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	"github.com/QuantumNous/new-api/oauth"
	"github.com/glebarez/sqlite"
	"gorm.io/gorm"
	gormlogger "gorm.io/gorm/logger"
)

func profileDatabase(t *testing.T) (*gorm.DB, *oauth.GenericOAuthProvider) {
	t.Helper()
	t.Setenv("MAIN_OAUTH_PROFILE_SYNC_ENABLED", "true")
	t.Setenv("CUSTOM_OAUTH_PKCE_PROVIDERS", "pingxingxian")
	db, err := gorm.Open(sqlite.Open(filepath.Join(t.TempDir(), "profile.db")), &gorm.Config{Logger: gormlogger.Default.LogMode(gormlogger.Silent)})
	if err != nil {
		t.Fatal(err)
	}
	if err := db.AutoMigrate(&model.User{}, &model.UserOAuthBinding{}, &model.CustomOAuthProvider{}); err != nil {
		t.Fatal(err)
	}
	config := model.CustomOAuthProvider{Id: 1, Slug: "pingxingxian", Enabled: true, ClientId: "parallellines-newapi", AuthStyle: oauth.AuthStyleInHeader,
		UserIdField: "sub", UsernameField: "preferred_username", DisplayNameField: "name", EmailField: "email",
		AuthorizationEndpoint: "https://pingxingxian.space/auth/oidc/auth", TokenEndpoint: "https://pingxingxian.space/auth/oidc/token",
		UserInfoEndpoint: "https://pingxingxian.space/auth/oidc/me"}
	if err := db.Create(&config).Error; err != nil {
		t.Fatal(err)
	}
	originalRedis, originalRegistration := common.RedisEnabled, common.RegisterEnabled
	common.RedisEnabled, common.RegisterEnabled = false, true
	t.Cleanup(func() {
		common.RedisEnabled, common.RegisterEnabled = originalRedis, originalRegistration
		sqlDB, _ := db.DB()
		sqlDB.Close()
	})
	return db, oauth.NewGenericOAuthProvider(&config)
}

func testMainProfile() *oauth.OAuthUser {
	return &oauth.OAuthUser{ProviderUserID: "53", Username: "main-name", DisplayName: "Main display", Email: "synthetic@example.invalid",
		Extra: map[string]any{"main_profile_verified": true}}
}

func insertProfileUser(t *testing.T, db *gorm.DB, id int, subject, username, email string) model.User {
	t.Helper()
	user := model.User{Id: id, Username: username, DisplayName: "Before", Email: email, Password: "synthetic-hash-do-not-change",
		Role: common.RoleRootUser, Status: common.UserStatusEnabled, Quota: 12345, UsedQuota: 678, Group: "default", AffCode: username}
	if err := db.Create(&user).Error; err != nil {
		t.Fatal(err)
	}
	if subject != "" {
		if err := db.Create(&model.UserOAuthBinding{UserId: id, ProviderId: 1, ProviderUserId: subject}).Error; err != nil {
			t.Fatal(err)
		}
	}
	return user
}

func TestMainProfileUpdatesOnlyBoundIdentityAndProfile(t *testing.T) {
	db, p := profileDatabase(t)
	before := insertProfileUser(t, db, 2, "53", "pl-53", "old@example.invalid")
	other := insertProfileUser(t, db, 3, "54", "pl-54", "other@example.invalid")
	for _, name := range []string{"main-name", "main-renamed"} {
		profile := testMainProfile()
		profile.Username = name
		user, created, err := findOrCreateMainProfileUser(db, p, profile, 0)
		if err != nil || created || user.Id != 2 || user.Username != name || user.Email != profile.Email {
			t.Fatal("profile not synchronized")
		}
		var after model.User
		db.First(&after, 2)
		if after.Role != before.Role || after.Quota != before.Quota || after.UsedQuota != before.UsedQuota || after.Password != before.Password || after.Group != before.Group {
			t.Fatal("protected fields changed")
		}
	}
	var unchanged model.User
	db.First(&unchanged, 3)
	if unchanged.Username != other.Username || unchanged.Email != other.Email {
		t.Fatal("another identity changed")
	}
	var bindings []model.UserOAuthBinding
	db.Order("id").Find(&bindings)
	if len(bindings) != 2 || bindings[0].UserId != 2 || bindings[0].ProviderUserId != "53" {
		t.Fatal("binding changed")
	}
}

func TestMainProfileCollisionRollsBackWithoutMergeIncludingDeletedUsers(t *testing.T) {
	for _, field := range []string{"username", "email", "deleted-email"} {
		t.Run(field, func(t *testing.T) {
			db, p := profileDatabase(t)
			before := insertProfileUser(t, db, 2, "53", "pl-53", "old@example.invalid")
			profile := testMainProfile()
			username, email := "other-name", "other@example.invalid"
			if field == "username" {
				username = profile.Username
			} else {
				email = "SYNTHETIC@example.invalid"
			}
			other := insertProfileUser(t, db, 3, "54", username, email)
			if field == "deleted-email" {
				db.Delete(&other)
			}
			_, _, err := findOrCreateMainProfileUser(db, p, profile, 0)
			var conflict *MainProfileConflictError
			if !errors.As(err, &conflict) {
				t.Fatal("collision did not explicitly fail")
			}
			var after model.User
			db.First(&after, 2)
			if after.Username != before.Username || after.Email != before.Email || after.DisplayName != before.DisplayName {
				t.Fatal("partial update during collision")
			}
		})
	}
}

func TestMainProfileNewRegistrationNoAliasAndNoMerge(t *testing.T) {
	db, p := profileDatabase(t)
	profile := testMainProfile()
	user, created, err := findOrCreateMainProfileUser(db, p, profile, 0)
	if err != nil || !created || user.Username != profile.Username || user.Role != common.RoleCommonUser {
		t.Fatal("registration mismatch")
	}
	profile.ProviderUserID = "different-sub"
	_, _, err = findOrCreateMainProfileUser(db, p, profile, 0)
	var conflict *MainProfileConflictError
	if !errors.As(err, &conflict) {
		t.Fatal("registered alias or merged same-profile new subject")
	}
	var count int64
	db.Model(&model.User{}).Count(&count)
	if count != 1 {
		t.Fatal("unexpected user count")
	}
}

func TestMainProfileDisabledDeletedUnverifiedAndProviderChangedFailClosed(t *testing.T) {
	for _, state := range []string{"disabled", "deleted", "unverified", "provider-changed"} {
		t.Run(state, func(t *testing.T) {
			db, p := profileDatabase(t)
			user := insertProfileUser(t, db, 2, "53", "pl-53", "old@example.invalid")
			profile := testMainProfile()
			switch state {
			case "disabled":
				db.Model(&user).Update("status", common.UserStatusDisabled)
			case "deleted":
				db.Delete(&user)
			case "unverified":
				profile.Extra["main_profile_verified"] = false
			case "provider-changed":
				db.Model(&model.CustomOAuthProvider{}).Where("id = ?", 1).Update("email_field", "other")
			}
			if _, _, err := findOrCreateMainProfileUser(db, p, profile, 0); err == nil {
				t.Fatal("unsafe profile login allowed")
			}
			var after model.User
			db.Unscoped().First(&after, 2)
			if after.Username != user.Username || after.Email != user.Email {
				t.Fatal("unsafe profile write")
			}
		})
	}
}
