package controller

import (
	"errors"
	"net/http"
	"net/url"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/i18n"
	"github.com/QuantumNous/new-api/oauth"
	"github.com/QuantumNous/new-api/pkg/oauthpkce"
	"github.com/gin-contrib/sessions"
	"github.com/gin-gonic/gin"
)

const pkceSessionKey = "custom_oauth_pkce_session"

// This candidate is intentionally single-process. Restart cancels pending logins.
// Do not deploy multiple replicas without a shared atomic transaction store.
var customPKCETransactions = oauthpkce.NewStore(5*time.Minute, 10000)

func pkceBinding(session sessions.Session, provider *oauth.GenericOAuthProvider) (oauthpkce.Binding, string, error) {
	binding, ok := session.Get(pkceSessionKey).(string)
	if !ok || binding == "" {
		return oauthpkce.Binding{}, "", oauthpkce.ErrInvalidState
	}
	userID := 0
	if session.Get("username") != nil {
		var valid bool
		userID, valid = session.Get("id").(int)
		if !valid || userID <= 0 {
			return oauthpkce.Binding{}, "", oauthpkce.ErrInvalidState
		}
	} else if session.Get("id") != nil {
		return oauthpkce.Binding{}, "", oauthpkce.ErrInvalidState
	}
	redirect, fingerprint, err := provider.PKCEConfiguration()
	return oauthpkce.Binding{Session: binding, UserID: userID, ProviderID: provider.GetProviderId(), Fingerprint: fingerprint}, redirect, err
}

func StartCustomOAuthPKCE(c *gin.Context) {
	c.Header("Cache-Control", "no-store")
	provider, ok := oauth.GetProvider(c.Param("provider")).(*oauth.GenericOAuthProvider)
	if !ok || !provider.IsEnabled() || !oauth.CustomPKCEEnabled(c.Param("provider")) {
		c.JSON(http.StatusBadRequest, gin.H{"success": false, "message": i18n.T(c, i18n.MsgOAuthNotEnabled)})
		return
	}
	provider = provider.Snapshot()
	session := sessions.Default(c)
	if value, ok := session.Get(pkceSessionKey).(string); !ok || value == "" {
		binding, err := oauthpkce.RandomValue()
		if err != nil {
			common.ApiError(c, err)
			return
		}
		session.Set(pkceSessionKey, binding)
	}
	if aff := c.Query("aff"); aff != "" {
		session.Set("aff", aff)
	}
	// Save before issuing a transaction; failed persistence must never redirect.
	if err := session.Save(); err != nil {
		common.ApiError(c, err)
		return
	}
	binding, redirect, err := pkceBinding(session, provider)
	if err != nil {
		common.ApiError(c, err)
		return
	}
	state, challenge, err := customPKCETransactions.Issue(binding)
	if err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, oauthpkce.ErrCapacity) {
			status = http.StatusTooManyRequests
		}
		c.JSON(status, gin.H{"success": false, "message": err.Error()})
		return
	}
	config := provider.GetConfig()
	authURL, _ := url.Parse(config.AuthorizationEndpoint) // validated above
	q := authURL.Query()
	q.Set("client_id", config.ClientId)
	q.Set("redirect_uri", redirect)
	q.Set("response_type", "code")
	q.Set("scope", config.Scopes)
	q.Set("state", state)
	q.Set("code_challenge", challenge)
	q.Set("code_challenge_method", "S256")
	// Verifiers and client secrets belong only at the token endpoint.
	q.Del("code_verifier")
	q.Del("client_secret")
	authURL.RawQuery = q.Encode()
	common.ApiSuccess(c, gin.H{"authorization_url": authURL.String()})
}

func consumeCustomOAuthPKCE(c *gin.Context, session sessions.Session, provider *oauth.GenericOAuthProvider) error {
	if !provider.IsEnabled() {
		return oauthpkce.ErrInvalidState
	}
	binding, redirect, err := pkceBinding(session, provider)
	if err != nil {
		return err
	}
	verifier, err := customPKCETransactions.Consume(c.Query("state"), binding)
	if err != nil {
		return err
	}
	c.Set(oauth.PKCEVerifierContextKey, verifier)
	c.Set(oauth.PKCERedirectContextKey, redirect)
	return nil
}
