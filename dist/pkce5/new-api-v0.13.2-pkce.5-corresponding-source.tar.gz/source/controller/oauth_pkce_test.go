package controller

import (
	"context"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/i18n"
	"github.com/QuantumNous/new-api/model"
	"github.com/QuantumNous/new-api/oauth"
	"github.com/QuantumNous/new-api/pkg/oauthpkce"
	"github.com/QuantumNous/new-api/setting/system_setting"
	"github.com/gin-contrib/sessions"
	"github.com/gin-contrib/sessions/cookie"
	"github.com/gin-gonic/gin"
)

type pkceBrowser struct{ cookies []*http.Cookie }
type pkceHarness struct {
	router   *gin.Engine
	config   *model.CustomOAuthProvider
	codes    map[string]string
	calls    atomic.Int32
	accepted atomic.Int32
}

func newPKCEHarness(t *testing.T) *pkceHarness {
	t.Helper()
	gin.SetMode(gin.TestMode)
	if err := i18n.Init(); err != nil {
		t.Fatal(err)
	}
	t.Setenv("CUSTOM_OAUTH_PKCE_PROVIDERS", "pkce-test")
	oldAddress, oldStore := system_setting.ServerAddress, customPKCETransactions
	system_setting.ServerAddress = "https://candidate.example"
	customPKCETransactions = oauthpkce.NewStore(5*time.Minute, 100)
	h := &pkceHarness{codes: make(map[string]string)}
	upstream := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		if r.URL.Path == "/userinfo" {
			// Deliberately stop before account/database operations. This suite tests
			// the authorization transaction and token exchange, not account creation.
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		if r.URL.Path != "/token" {
			t.Errorf("unexpected upstream path %s", r.URL.Path)
			w.WriteHeader(404)
			return
		}
		h.calls.Add(1)
		if err := r.ParseForm(); err != nil {
			t.Error(err)
		}
		clientID, secret, basic := r.BasicAuth()
		if !basic || clientID != "fixture-client" || secret != "fixture-secret" {
			t.Error("client_secret_basic contract failed")
		}
		if r.PostForm.Get("client_secret") != "" {
			t.Error("Basic credentials duplicated into form")
		}
		if r.PostForm.Get("grant_type") != "authorization_code" {
			t.Error("wrong grant")
		}
		code, verifier := r.PostForm.Get("code"), r.PostForm.Get("code_verifier")
		valid := false
		if code == "legacy" {
			valid = verifier == "" && r.PostForm.Get("redirect_uri") == "https://candidate.example/oauth/legacy-test"
		} else {
			expected, exists := h.codes[code]
			valid = exists && len(verifier) == 43 && oauthpkce.Challenge(verifier) == expected &&
				r.PostForm.Get("redirect_uri") == "https://candidate.example/oauth/pkce-test"
		}
		if !valid {
			w.WriteHeader(400)
			_, _ = w.Write([]byte(`{"error":"invalid_grant"}`))
			return
		}
		h.accepted.Add(1)
		_, _ = w.Write([]byte(`{"access_token":"synthetic-test-token","token_type":"Bearer"}`))
	}))
	oldTransport := http.DefaultTransport
	http.DefaultTransport = upstream.Client().Transport
	h.config = &model.CustomOAuthProvider{
		Id: 77, Slug: "pkce-test", Name: "PKCE fixture", Enabled: true,
		ClientId: "fixture-client", ClientSecret: "fixture-secret", AuthStyle: 2,
		AuthorizationEndpoint: upstream.URL + "/authorize", TokenEndpoint: upstream.URL + "/token",
		UserInfoEndpoint: upstream.URL + "/userinfo", Scopes: "openid profile",
		UserIdField: "sub", UsernameField: "preferred_username", DisplayNameField: "name",
	}
	oauth.RegisterCustom("pkce-test", oauth.NewGenericOAuthProvider(h.config))
	t.Cleanup(func() {
		http.DefaultTransport = oldTransport
		upstream.Close()
		oauth.UnregisterCustomProvider("pkce-test")
		oauth.UnregisterCustomProvider("legacy-test")
		system_setting.ServerAddress, customPKCETransactions = oldAddress, oldStore
	})
	h.router = gin.New()
	store := cookie.NewStore([]byte("synthetic-session-test-signing-key"))
	store.Options(sessions.Options{Path: "/", HttpOnly: true, SameSite: http.SameSiteStrictMode})
	h.router.Use(sessions.Sessions("session", store))
	h.router.POST("/api/oauth/:provider/start", StartCustomOAuthPKCE)
	h.router.GET("/api/oauth/state", GenerateOAuthCode)
	h.router.GET("/api/oauth/:provider", HandleOAuth)
	h.router.POST("/test/session/:id", func(c *gin.Context) {
		s := sessions.Default(c)
		id, _ := strconv.Atoi(c.Param("id"))
		if id == 0 {
			s.Delete("id")
			s.Delete("username")
		} else {
			s.Set("id", id)
			s.Set("username", "fixture-user")
		}
		if err := s.Save(); err != nil {
			t.Error(err)
		}
		c.Status(200)
	})
	return h
}

func (h *pkceHarness) request(b *pkceBrowser, method, path string) *httptest.ResponseRecorder {
	req := httptest.NewRequest(method, path, nil)
	for _, c := range b.cookies {
		req.AddCookie(c)
	}
	w := httptest.NewRecorder()
	h.router.ServeHTTP(w, req)
	if cookies := w.Result().Cookies(); len(cookies) > 0 {
		b.cookies = cookies
	}
	return w
}

func (h *pkceHarness) start(t *testing.T, b *pkceBrowser) (string, string) {
	t.Helper()
	w := h.request(b, "POST", "/api/oauth/pkce-test/start")
	var response struct {
		Success bool
		Data    struct {
			URL string `json:"authorization_url"`
		}
	}
	if err := common.Unmarshal(w.Body.Bytes(), &response); err != nil {
		t.Fatal(err)
	}
	if w.Code != 200 || !response.Success {
		t.Fatalf("start failed: %d %s", w.Code, w.Body.String())
	}
	if w.Header().Get("Cache-Control") != "no-store" {
		t.Error("authorization response must not be cached")
	}
	u, err := url.Parse(response.Data.URL)
	if err != nil {
		t.Fatal(err)
	}
	q := u.Query()
	if q.Get("code_challenge_method") != "S256" || q.Get("redirect_uri") != "https://candidate.example/oauth/pkce-test" ||
		q.Get("client_id") != "fixture-client" || q.Get("response_type") != "code" {
		t.Fatal("bad authorization parameters")
	}
	if q.Has("code_verifier") || strings.Contains(w.Body.String(), "fixture-secret") {
		t.Fatal("authorization response leaked a secret")
	}
	for _, c := range b.cookies {
		if c.Name == "session" && !c.HttpOnly {
			t.Error("session must be HttpOnly")
		}
	}
	return q.Get("state"), q.Get("code_challenge")
}

func callbackPath(state, code string) string {
	return "/api/oauth/pkce-test?" + url.Values{"state": {state}, "code": {code}}.Encode()
}

func TestCustomPKCERejectsCrossSessionAndReplay(t *testing.T) {
	h := newPKCEHarness(t)
	a, b := &pkceBrowser{}, &pkceBrowser{}
	state, challenge := h.start(t, a)
	h.codes["valid"] = challenge
	h.start(t, b)
	if w := h.request(b, "GET", callbackPath(state, "valid")); w.Code != 403 {
		t.Fatalf("cross-session status %d", w.Code)
	}
	if h.calls.Load() != 0 {
		t.Fatal("wrong session reached upstream")
	}
	stale := &pkceBrowser{cookies: a.cookies}
	h.request(a, "GET", callbackPath(state, "valid"))
	if h.accepted.Load() != 1 {
		t.Fatal("correct session/verifier did not reach upstream")
	}
	if w := h.request(stale, "GET", callbackPath(state, "valid")); w.Code != 403 {
		t.Fatal("stale signed cookie replay accepted")
	}
	if h.calls.Load() != 1 {
		t.Fatal("replay reached token endpoint")
	}
}

func TestCustomPKCECodeFailuresConsumeTransaction(t *testing.T) {
	for _, code := range []string{"", "wrong-code", "wrong-challenge"} {
		t.Run(code, func(t *testing.T) {
			h := newPKCEHarness(t)
			b := &pkceBrowser{}
			state, challenge := h.start(t, b)
			h.codes["valid"] = challenge
			h.codes["wrong-challenge"] = oauthpkce.Challenge("different-verifier")
			h.request(b, "GET", callbackPath(state, code))
			if h.accepted.Load() != 0 {
				t.Fatal("invalid code/PKCE accepted")
			}
			before := h.calls.Load()
			if code == "" && before != 0 {
				t.Fatal("empty code reached upstream")
			}
			if w := h.request(b, "GET", callbackPath(state, "valid")); w.Code != 403 {
				t.Fatal("failed transaction was reusable")
			}
			if h.calls.Load() != before {
				t.Fatal("replayed failed transaction reached upstream")
			}
		})
	}
}

func TestCustomPKCEMultipleTabsAndLoginChanges(t *testing.T) {
	h := newPKCEHarness(t)
	b := &pkceBrowser{}
	first, c1 := h.start(t, b)
	second, c2 := h.start(t, b)
	h.codes["first"], h.codes["second"] = c1, c2
	h.request(b, "POST", "/test/session/5")
	if w := h.request(b, "GET", callbackPath(first, "first")); w.Code != 403 {
		t.Fatal("anonymous transaction became account binding")
	}
	h.request(b, "POST", "/test/session/0")
	h.request(b, "GET", callbackPath(second, "second"))
	h.request(b, "GET", callbackPath(first, "first"))
	if h.accepted.Load() != 2 {
		t.Fatal("same-session tabs did not complete independently")
	}
}

func TestCustomPKCEFirstCookieRaceFailsClosed(t *testing.T) {
	h := newPKCEHarness(t)
	tab1, tab2 := &pkceBrowser{}, &pkceBrowser{}
	first, c1 := h.start(t, tab1)
	second, c2 := h.start(t, tab2)
	h.codes["first"], h.codes["second"] = c1, c2
	// Both starts lacked a cookie; the browser kept the second Set-Cookie.
	if w := h.request(tab2, "GET", callbackPath(first, "first")); w.Code != 403 {
		t.Fatal("first-cookie race crossed sessions")
	}
	h.request(tab2, "GET", callbackPath(second, "second"))
	if h.accepted.Load() != 1 {
		t.Fatal("surviving cookie transaction failed")
	}
}

func TestCustomPKCEProviderConfigurationAndMissingState(t *testing.T) {
	h := newPKCEHarness(t)
	b := &pkceBrowser{}
	state, challenge := h.start(t, b)
	h.codes["valid"] = challenge
	for _, wrong := range []string{"", "unknown"} {
		if w := h.request(b, "GET", callbackPath(wrong, "valid")); w.Code != 403 {
			t.Fatal("bad state accepted")
		}
	}
	changed := *h.config
	changed.AccessPolicy = `{"logic":"and","conditions":[{"field":"allowed","op":"eq","value":true}]}`
	oauth.RegisterCustom(changed.Slug, oauth.NewGenericOAuthProvider(&changed))
	if w := h.request(b, "GET", callbackPath(state, "valid")); w.Code != 403 {
		t.Fatal("configuration changed during authorization")
	}
	if h.calls.Load() != 0 {
		t.Fatal("invalid transaction reached upstream")
	}
	oauth.RegisterCustom(h.config.Slug, oauth.NewGenericOAuthProvider(h.config))
	h.request(b, "GET", callbackPath(state, "valid"))
	if h.accepted.Load() != 1 {
		t.Fatal("invalid attempt consumed legitimate state")
	}
}

func TestCustomPKCECannotBypassControllerAndLegacyIsUnchanged(t *testing.T) {
	h := newPKCEHarness(t)
	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	_, err := oauth.NewGenericOAuthProvider(h.config).ExchangeToken(context.Background(), "valid", c)
	if err == nil || h.calls.Load() != 0 {
		t.Fatal("PKCE-required exchange accepted no validated transaction")
	}
	legacy := *h.config
	legacy.Id, legacy.Slug = 78, "legacy-test"
	oauth.RegisterCustom(legacy.Slug, oauth.NewGenericOAuthProvider(&legacy))
	b := &pkceBrowser{}
	w := h.request(b, "GET", "/api/oauth/state")
	var response struct{ Data string }
	if err := common.Unmarshal(w.Body.Bytes(), &response); err != nil {
		t.Fatal(err)
	}
	h.request(b, "GET", "/api/oauth/legacy-test?state="+response.Data+"&code=legacy")
	if h.accepted.Load() != 1 {
		t.Fatal("legacy provider behavior changed")
	}
	if w := h.request(b, "POST", "/api/oauth/legacy-test/start"); w.Code != 400 {
		t.Fatal("non-opt-in provider started PKCE")
	}
}
