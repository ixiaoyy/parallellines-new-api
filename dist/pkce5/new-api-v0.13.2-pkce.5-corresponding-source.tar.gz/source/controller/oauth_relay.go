package controller

import (
	"errors"
	"net/http"
	"strconv"
	"strings"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/dto"
	"github.com/QuantumNous/new-api/model"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// Discovery is free and follows the authenticated user's actual channel group.
// Missing prices still fail in the unchanged paid relay/billing pipeline.
func ListChatOAuthRelayModels(c *gin.Context) {
	group := common.GetContextKeyString(c, constant.ContextKeyUsingGroup)
	enabled := make(map[string]bool)
	for _, name := range model.GetGroupEnabledModels(group) {
		enabled[name] = true
	}
	models := make([]dto.OpenAIModels, 0, 3)
	for _, name := range strings.Split(model.OAuthRelayModelLimits, ",") {
		if enabled[name] {
			models = append(models, dto.OpenAIModels{Id: name, Object: "model", OwnedBy: "custom"})
		}
	}
	c.JSON(http.StatusOK, gin.H{"object": "list", "data": models})
}

// The root-only route never returns the key and does not recreate a missing or
// revoked credential. Existing user-disable/unbind controls also revoke access.
func RevokeChatOAuthRelayCredential(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil || id <= 0 {
		c.AbortWithStatusJSON(400, gin.H{"success": false, "message": "invalid user id"})
		return
	}
	if err := model.RevokeOAuthRelayToken(id); err != nil {
		status := 500
		if errors.Is(err, gorm.ErrRecordNotFound) {
			status = 404
		}
		c.JSON(status, gin.H{"success": false, "message": "internal credential not found or revocation failed"})
		return
	}
	c.JSON(200, gin.H{"success": true, "message": ""})
}
