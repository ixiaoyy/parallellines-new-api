package controller

import (
	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/relay/helper"
	"github.com/QuantumNous/new-api/service"
	"github.com/QuantumNous/new-api/types"
	"github.com/gin-gonic/gin"
)

// Never append an ordinary HTTP JSON body after SSE has begun. This is only
// used for this policy's explicit un-settled usage failure; native refund and
// error auditing still run in the enclosing relay controller.
func writeOpenAIStandardStreamError(c *gin.Context, format types.RelayFormat, err *types.NewAPIError) bool {
	if err == nil || err.GetErrorCode() != service.OpenAIStandardUsageErrorCode || !c.Writer.Written() || !c.GetBool(string(constant.ContextKeyIsStream)) {
		return false
	}
	if format == types.RelayFormatOpenAIResponses {
		next := 0
		if value, ok := c.Get("openai_standard_last_sequence"); ok {
			if n, valid := value.(int); valid && n >= 0 && n < 1000000000 {
				next = n + 1
			}
		}
		c.Render(-1, common.CustomEvent{Data: "event: error\n"})
		_ = helper.ObjectData(c, gin.H{"type": "error", "code": string(err.GetErrorCode()), "message": err.ToOpenAIError().Message, "param": nil, "sequence_number": next})
	} else {
		_ = helper.ObjectData(c, gin.H{"error": err.ToOpenAIError()})
		helper.Done(c)
	}
	return true
}
