package controller

import (
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/service"
	"github.com/QuantumNous/new-api/types"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/require"
	"net/http/httptest"
	"testing"
)

func TestOpenAIStandardStreamErrorProtocol(t *testing.T) {
	gin.SetMode(gin.TestMode)
	for _, format := range []types.RelayFormat{types.RelayFormatOpenAI, types.RelayFormatOpenAIResponses} {
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("GET", "/", nil)
		c.Set(string(constant.ContextKeyIsStream), true)
		c.Set("openai_standard_last_sequence", 7)
		c.Writer.WriteHeader(200)
		c.Writer.Write([]byte("data: prior\n\n"))
		require.True(t, writeOpenAIStandardStreamError(c, format, service.OpenAIStandardUsageError("missing_final_usage")))
		body := w.Body.String()
		require.Contains(t, body, "openai_standard_usage_unsettled")
		require.NotContains(t, body, "response.completed")
		if format == types.RelayFormatOpenAIResponses {
			require.Contains(t, body, "event: error")
			require.Contains(t, body, `"type":"error"`)
			require.Contains(t, body, `"sequence_number":8`)
			require.NotContains(t, body, "[DONE]")
		} else {
			require.Contains(t, body, "[DONE]")
			require.Contains(t, body, `"error":`)
		}
	}
	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	c.Request = httptest.NewRequest("GET", "/", nil)
	require.False(t, writeOpenAIStandardStreamError(c, types.RelayFormatOpenAI, service.OpenAIStandardUsageError("missing_usage")))
	require.Empty(t, w.Body.String())
}
