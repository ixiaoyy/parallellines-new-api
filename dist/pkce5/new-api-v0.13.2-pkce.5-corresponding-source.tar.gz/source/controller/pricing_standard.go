package controller

import (
	"strings"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/dto"
	"github.com/QuantumNous/new-api/model"
	"github.com/QuantumNous/new-api/service"
	"github.com/QuantumNous/new-api/setting/model_setting"
)

type pricingWithStandardPolicy struct {
	model.Pricing
	StandardPricing      *service.OpenAIStandardPricingInfo `json:"standard_pricing,omitempty"`
	StandardPricingState string                             `json:"standard_pricing_state,omitempty"`
}

// The API-key column is not selected. Settings are inspected only to reject
// unsupported routing; no channel settings or credentials enter the response.
type standardPricingChannel struct {
	Model          string
	ChannelType    int
	Status         int
	BaseURL        string
	ModelMapping   string
	Setting        string
	Settings       string
	ParamOverride  string
	HeaderOverride string
}

func directStandardChannel(row standardPricingChannel) bool {
	base := strings.TrimRight(row.BaseURL, "/")
	return row.ChannelType == constant.ChannelTypeOpenAI && row.Status == common.ChannelStatusEnabled &&
		(base == "" || base == "https://api.openai.com" || base == "https://api.openai.com/v1")
}

func emptyStandardOverrides(value string) bool {
	if strings.TrimSpace(value) == "" {
		return true
	}
	var fields map[string]any
	return common.UnmarshalJsonStr(value, &fields) == nil && len(fields) == 0
}

func reviewedStandardChannel(row standardPricingChannel) bool {
	var mapping map[string]string
	if strings.TrimSpace(row.ModelMapping) != "" && common.UnmarshalJsonStr(row.ModelMapping, &mapping) != nil {
		return false
	}
	if _, mapped := mapping[row.Model]; mapped {
		return false
	}
	var setting dto.ChannelSettings
	var other dto.ChannelOtherSettings
	if strings.TrimSpace(row.Setting) != "" && common.UnmarshalJsonStr(row.Setting, &setting) != nil {
		return false
	}
	if strings.TrimSpace(row.Settings) != "" && common.UnmarshalJsonStr(row.Settings, &other) != nil {
		return false
	}
	return !setting.PassThroughBodyEnabled && setting.Proxy == "" && !other.AllowServiceTier &&
		emptyStandardOverrides(row.ParamOverride) && emptyStandardOverrides(row.HeaderOverride)
}

func applyOpenAIStandardPricing(pricing []model.Pricing, channels []standardPricingChannel, enabled, globalPassthrough bool) []pricingWithStandardPolicy {
	rows := make(map[string][]standardPricingChannel)
	for _, row := range channels {
		rows[row.Model] = append(rows[row.Model], row)
	}
	result := make([]pricingWithStandardPolicy, 0, len(pricing))
	for _, item := range pricing {
		entry := pricingWithStandardPolicy{Pricing: item}
		policy, known := service.GetOpenAIStandardPricing(item.ModelName)
		matches := rows[item.ModelName]
		if known && len(matches) > 0 {
			direct, reviewed := true, !globalPassthrough
			for _, row := range matches {
				direct = direct && directStandardChannel(row)
				reviewed = reviewed && reviewedStandardChannel(row)
			}
			// The native row is aggregated across groups/channels. Never label a
			// mixed-provider row as if this narrow policy applies to all routes.
			if direct {
				entry.StandardPricing = &policy
				entry.StandardPricingState = "enabled"
				if !enabled {
					entry.StandardPricingState = "disabled"
				} else if !reviewed {
					entry.StandardPricingState = "unsupported_channel_settings"
				}
				// These fields preserve the original ratio display, but the exact
				// USD schedule below is authoritative and cannot be edited via maps.
				entry.ModelRatio = policy.Input * common.QuotaPerUnit / 1000000
				entry.CompletionRatio = policy.Output / policy.Input
				cacheRatio := policy.CacheRead / policy.Input
				entry.CacheRatio = &cacheRatio
				entry.CreateCacheRatio = nil
				entry.ModelPrice, entry.QuotaType = 0, 0
				entry.BillingMode, entry.BillingExpr = "openai_standard", ""
				entry.ImageRatio, entry.AudioRatio, entry.AudioCompletionRatio = nil, nil, nil
			}
		}
		result = append(result, entry)
	}
	return result
}

func pricingWithOpenAIStandardPolicy(pricing []model.Pricing) ([]pricingWithStandardPolicy, error) {
	var rows []standardPricingChannel
	if err := model.DB.Table("abilities").Select("abilities.model, channels.type AS channel_type, channels.status, channels.base_url, channels.model_mapping, channels.setting, channels.settings, channels.param_override, channels.header_override").
		Joins("JOIN channels ON channels.id = abilities.channel_id").
		Where("abilities.enabled = ? AND abilities.model IN ?", true, []string{"gpt-6-luna", "gpt-6.1-terra", "gpt-6.1-sol"}).Scan(&rows).Error; err != nil {
		return nil, err
	}
	return applyOpenAIStandardPricing(pricing, rows, service.OpenAIStandardPolicyConfigured(), model_setting.GetGlobalSettings().PassThroughRequestEnabled), nil
}
