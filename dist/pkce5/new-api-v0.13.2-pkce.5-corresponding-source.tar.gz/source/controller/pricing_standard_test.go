package controller

import (
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/model"
)

func TestOpenAIStandardPricingDisplay(t *testing.T) {
	channel := standardPricingChannel{Model: "gpt-6-luna", ChannelType: constant.ChannelTypeOpenAI, Status: common.ChannelStatusEnabled, BaseURL: "https://api.openai.com"}
	row := model.Pricing{ModelName: channel.Model, ModelRatio: 999, CompletionRatio: 999, ModelPrice: 999, QuotaType: 1, BillingMode: "tiered_expr", BillingExpr: "old", EnableGroup: []string{"default"}}
	result := applyOpenAIStandardPricing([]model.Pricing{row}, []standardPricingChannel{channel}, true, false)
	got := result[0]
	if got.StandardPricingState != "enabled" || got.StandardPricing == nil || got.StandardPricing.Input != .1 || got.StandardPricing.CacheWrite30m != .125 || got.StandardPricing.CacheWrite12h != .25 || got.StandardPricing.LongContextThreshold != 272000 {
		t.Fatalf("incomplete standard policy: %+v", got)
	}
	if got.ModelRatio != .1*common.QuotaPerUnit/1000000 || got.CompletionRatio != 5 || got.BillingMode != "openai_standard" || got.BillingExpr != "" || got.ModelPrice != 0 || got.QuotaType != 0 || got.CreateCacheRatio != nil {
		t.Fatalf("legacy ratio display must not override the policy: %+v", got)
	}
	if row.ModelRatio != 999 || row.BillingExpr != "old" {
		t.Fatal("shared native pricing cache was mutated")
	}
	for _, tc := range []struct {
		name                 string
		enabled, passthrough bool
		want                 string
	}{
		{"disabled", false, false, "disabled"},
		{"passthrough", true, true, "unsupported_channel_settings"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			got := applyOpenAIStandardPricing([]model.Pricing{row}, []standardPricingChannel{channel}, tc.enabled, tc.passthrough)[0]
			if got.StandardPricingState != tc.want {
				t.Fatal(got.StandardPricingState)
			}
		})
	}
}

func TestOpenAIStandardPricingChannelIsolation(t *testing.T) {
	base := standardPricingChannel{Model: "gpt-6-luna", ChannelType: constant.ChannelTypeOpenAI, Status: common.ChannelStatusEnabled, BaseURL: "https://api.openai.com"}
	row := model.Pricing{ModelName: base.Model, ModelRatio: 123, EnableGroup: []string{"default"}}
	other := base
	other.BaseURL = "https://other-provider.example"
	for _, channels := range [][]standardPricingChannel{{other}, {base, other}, {}} {
		got := applyOpenAIStandardPricing([]model.Pricing{row}, channels, true, false)[0]
		if got.StandardPricing != nil || got.ModelRatio != 123 {
			t.Fatal("unrelated or mixed provider pricing changed")
		}
	}
	for _, value := range []standardPricingChannel{
		{Model: base.Model, ModelMapping: `{"gpt-6-luna":"other"}`},
		{Model: base.Model, Setting: `{"proxy":"configured"}`},
		{Model: base.Model, Settings: `{"allow_service_tier":true}`},
		{Model: base.Model, ParamOverride: `{"service_tier":"fast"}`},
		{Model: base.Model, HeaderOverride: `{"Authorization":"placeholder"}`},
	} {
		value.ChannelType, value.Status, value.BaseURL = base.ChannelType, base.Status, base.BaseURL
		got := applyOpenAIStandardPricing([]model.Pricing{row}, []standardPricingChannel{value}, true, false)[0]
		if got.StandardPricingState != "unsupported_channel_settings" {
			t.Fatal("unsafe channel shown as enabled")
		}
	}
}
