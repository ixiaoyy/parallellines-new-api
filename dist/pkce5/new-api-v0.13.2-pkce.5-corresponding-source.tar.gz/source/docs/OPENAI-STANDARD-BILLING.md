# OpenAI standard quota policy

`OPENAI_STANDARD_BILLING_ENABLED=true` activates the approved site quota policy
`openai-standard-2026-10-30`. This is the site's quota schedule, not a guarantee
of the upstream account's invoice or discounts. No balances are changed by this
patch. Existing PKCE, identity binding and private per-user credential guards
remain required.

## Scope and configuration

The policy covers exact model IDs `gpt-6-luna`, `gpt-6.1-terra`, and
`gpt-6.1-sol` on an OpenAI channel using the official default URL,
`https://api.openai.com`, or `https://api.openai.com/v1`. Only native Chat
Completions and Responses requests are supported. Other endpoints in this
scope fail before sending upstream. Other models, channel types and base URLs
retain their existing billing behavior.

For these three official-direct models, an unset/false feature flag deliberately
fails closed even if legacy price maps are configured. Do not use flag=false as
a return to static billing. Deploy/recover with this policy enabled; if access
must be suspended, disable the Chat OAuth relay rather than rolling back to an
older billing binary or restoring an older balance database.

The selected channel/model is checked again immediately before the adapter
sends a request. Model mapping, another selected channel, passthrough, a proxy,
parameter/header overrides, service-tier forwarding, and Chat-to-Responses
conversion are rejected for this policy. Request service tier must be absent
or `default`. Chat cache-control TTL must be `30m`; ambiguous Chat `12h`
breakpoints are rejected instead of being charged as `30m`.

## Rates and calculation

Sources checked 2026-10-30: [official pricing](https://developers.openai.com/api/docs/pricing),
the three official model pages, Chat/Responses usage schemas and prompt caching
documentation. USD per 1,000,000 tokens:

| Model | Ordinary input | Output | Cache read | Cache write 30m | Cache write 12h |
| --- | ---: | ---: | ---: | ---: | ---: |
| gpt-6-luna | 0.10 | 0.50 | 0.01 | 0.125 | 0.25 |
| gpt-6.1-terra | 1.00 | 5.00 | 0.05 | 1.25 | 2.50 |
| gpt-6.1-sol | 2.00 | 10.00 | 0.10 | 2.50 | 5.00 |

Input total `P` includes cache read and writes. Ordinary input is
`P - cache_read - write_30m - write_12h`; writes are not charged twice.
When actual `P > 272000`, all input/cache rates multiply by 2 and the output
rate by 1.5 for the entire request. Exactly 272000 uses short-context rates.
The resulting dollar amount multiplies by the native quota-per-dollar value
and group ratio snapshotted at reservation. Existing native tool surcharges
are retained, then the total is rounded once to the nearest quota unit
(nonempty token usage has a minimum of one unit).

Native base ratio maps may be populated for the original pricing display; they
do not replace this policy. Display metadata explicitly describes the 30m/12h
write tiers and long-context threshold; Claude 5m/1h fields are not repurposed.

## Reservation, usage and failures

The native preconsume/settlement path is retained. Reservation conservatively
uses the highest supported input/write and long-context rates, with the stated
output cap when available. This is a reservation, not the final charge:
settlement refunds the excess. A very small balance can therefore be rejected
before a short request whose actual final cost would have fit.

Core input/output/total usage fields must be present, nonnegative integers and
consistent. Optional cache counters default to zero when omitted. Responses
with cache writes require an explicit 30m/12h breakdown matching total writes.
Explicit all-zero usage is accepted only when no generated content is present.
No missing usage is replaced with a local token estimate or a zero charge.

Chat streaming always requests upstream usage while preserving the client's
output preference. Identical duplicate usage snapshots are validated once,
never accumulated; conflicting snapshots fail. Responses `completed` and
`incomplete` terminal events with valid usage both settle normally. A missing,
invalid or interrupted terminal usage produces `openai_standard_usage_unsettled`,
skips automatic retries, follows native reservation refund/error auditing, and
does not record a successful zero-cost request. A streaming error is sent using
the corresponding Chat or Responses error protocol. This cannot prove whether
the provider billed an interrupted request; operator reconciliation may be
needed. Logs contain bounded reason codes and counts, not raw requests or keys.

## Offline verification

Tests use synthetic payloads and a transport that never opens a network socket.
They cover fixed rate fixtures, cache partitions, exact threshold boundaries,
price/group snapshots, endpoint and feature-off guards, unrelated channels,
nonstream/stream usage, valid incomplete responses, missing/conflicting usage,
client usage hiding and protocol-visible streaming errors. No paid upstream
request or real-invoice parity test is included.
