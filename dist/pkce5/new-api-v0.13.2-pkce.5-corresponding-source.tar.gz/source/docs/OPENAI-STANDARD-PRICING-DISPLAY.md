# Standard pricing in the native price catalogue

`OPENAI_STANDARD_BILLING_ENABLED=true` activates the versioned policy implemented
in `service/openai_standard_billing.go`. It is the site's quota schedule, not a
claim about a provider invoice. The exact same exported policy supplies
`GET /api/pricing` and the existing native card, table and detail price views.
No parallel editable legacy ratio maps are written. General ratio-map edits do
not override this policy; the detail view states this explicitly.

Only the three reviewed model IDs are annotated, and only if every enabled route
for that catalogue model uses the original OpenAI channel type and official
direct endpoint. Mixed-provider rows retain their native presentation. A stopped
policy or incompatible channel settings are labelled unavailable rather than
displaying the native fallback ratio as a valid price.

## Readback contract

For each of `gpt-6-luna`, `gpt-6.1-terra`, `gpt-6.1-sol`, verify:

- `standard_pricing_state` is `enabled`.
- `standard_pricing.policy_version` is `openai-standard-2026-10-30`.
- Currency is `USD`; unit is `per_1000000_tokens`.
- Source is `https://developers.openai.com/api/docs/pricing`; checked date is
  `2026-10-30`.
- `quota_policy_not_provider_invoice` is true.
- Long-context threshold is 272000 input tokens; **above** that threshold the
  full request's input/cache prices multiply by 2 and output by 1.5.

| Model | Input | Output | Cache read | 30m write | 12h write |
| --- | ---: | ---: | ---: | ---: | ---: |
| gpt-6-luna | 0.10 | 0.50 | 0.01 | 0.125 | 0.25 |
| gpt-6.1-terra | 1 | 5 | 0.05 | 1.25 | 2.50 |
| gpt-6.1-sol | 2 | 10 | 0.10 | 2.50 | 5 |

The 12-hour write price is explicitly labelled **Responses only**. The reviewed
Chat policy supports 30-minute writes; it does not guess a mixed-TTL Chat
contract or reuse Claude cache-duration labels.

The API also emits native base ratio fields for the existing ratio view, derived
from the same schedule and current quota denomination. Monetary UI prices use
the USD metadata directly, so they do not assume a hard-coded quota denomination.
The user's effective group multiplier and existing currency-display conversion
still apply. The per-thousand display preserves enough decimal places to avoid
showing Luna cache reads as zero.

## Focused checks

- Go: `go test ./controller -run '^TestOpenAIStandardPricing' -count=1`.
- Frontend: `bun test src/helpers/openai-standard-pricing.test.js`.
- Rebuild the frontend; the previous pkce.1 assets cannot display these fields.
- After release, read the native endpoint and open a model's native pricing
  detail to verify prices, duration labels, long-context note and source/date.

These checks do not generate model responses or change balances. Rendering on
the deployed page remains a release acceptance check, distinct from the helper
unit tests.
