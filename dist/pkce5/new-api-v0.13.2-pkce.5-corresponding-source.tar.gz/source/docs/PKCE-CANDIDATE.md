# Custom OAuth PKCE candidate

Base: official QuantumNous/new-api v0.13.2, commit
`bee339d279ccecbf8c8a89e14ddbbd902f78bd5d`. Source was obtained from the
fixed-commit official GitHub archive. This is a local candidate patch, not an
upstream release. The original UI, branding, database schema, role assignment,
quota behavior and existing providers are retained.

## Scope and activation

Set `CUSTOM_OAUTH_PKCE_PROVIDERS` to a comma-separated list of **custom provider
slugs**, for example `pingxingxian`. The default is empty (upstream behavior).
This is an explicit server-side requirement, not a browser preference. An
allowlisted provider rejects legacy callbacks without a matching PKCE transaction.

Configure the existing custom OAuth provider normally, including client ID,
client secret, endpoints, scopes, field mappings and `auth_style=2` for Basic.
`ServerAddress` must be the trusted public HTTPS origin. Its callback is
`ServerAddress/oauth/<slug>`. All three provider endpoints must use HTTPS.
The configuration is not applied by this patch.

The unchanged login button obtains an authorization URL with
`POST /api/oauth/<slug>/start`. This uses the existing rate limiter and a
`Cache-Control: no-store` response. A 256-bit random verifier remains exclusively
in a bounded in-process store. The signed HttpOnly session cookie carries only a
random binding ID, never the verifier. State and the S256 challenge are returned
in the authorization URL.

Transactions bind the session, initiating local user ID (including anonymous),
provider ID, trusted redirect and a fingerprint of the full provider configuration.
The callback snapshots the provider, checks every binding and atomically consumes
the transaction **before** a token request, including the existing-account bind
path. The token request adds the verified `code_verifier` and frozen redirect.
Missing/invalid state, expired state, wrong session/user/provider/configuration,
and replay cannot fall back to the old flow. An invalid code burns its own valid
transaction and requires a new login attempt.

## Deliberate limits

- This remains the upstream OAuth authorization-code + UserInfo identity flow.
  The returned ID Token is not used for authentication. This patch does not add
  nonce or ID Token validation and must not be described as doing so.
- Single application process only. Transactions expire after five minutes, with
  at most eight pending transactions per browser binding and 10,000 total.
  Restart or routing a callback to a different process fails closed. Multiple
  replicas require a separate review and a shared atomic transaction store.
- Existing-cookie tabs have independent transactions while their session principal
  stays unchanged. Once one tab actually logs in, other anonymous transactions
  are rejected rather than being converted into account-binding attempts.
  Simultaneous first starts without any cookie can race their Set-Cookie responses;
  the losing tab fails closed and must restart authorization. It cannot inherit
  the winning tab's transaction.
- Network retries after a consumed callback cannot resend the token exchange.
  A lost successful response may require a fresh authorization.
- This does not add SSO role inheritance, admin claims, quota synchronization,
  relay-token provisioning, Open WebUI token delivery, or main-site logout/
  authorization-expiry propagation. New accounts retain upstream role 1.
- No persistent secret, real account, provider configuration, server deployment,
  or paid model call is created by the tests. Upstream DEBUG logging must remain
  disabled for real OAuth credentials, as its existing token debug logs are
  outside this patch's scope.

## Validation

Use the upstream Dockerfile's Go 1.26.1 builder (go.mod minimum is 1.25.1).
Frontend dependencies are installed from the existing bun.lock with
`bun install --frozen-lockfile`, then `bun run build`.

Targeted tests:

```sh
go test ./pkg/oauthpkce
go test ./controller -run '^TestCustomPKCE' -count=1
go test ./router -run '^TestCustomPKCERouteRegistration$' -count=1
```

Store tests exercise RFC 7636 S256, unpredictable values, all binding failures,
expiry, replay, multi-tab completion, capacity limits and concurrent single-use
consumption. Controller tests use a local TLS mock token endpoint that validates
Basic auth, redirect and S256, and deliberately stops at UserInfo before any
account/database writes. They cover missing/wrong codes, wrong verifier challenge,
cross-session use, stale-cookie replay, configuration changes, login-state changes,
the first-cookie race, required-verifier enforcement and the legacy provider path.
These are protocol tests; a real main-site SSO flow has not been executed.

Recorded local results (2026-10-30):

- Go 1.26.1: `go test ./controller ./router -run '^TestCustomPKCE' -count=1`
  passed; `go test ./oauth ./pkg/oauthpkce -count=1` passed (oauth has no tests).
- Bun 1.4.4: frozen dependency install and full Vite production build passed.
- `bun test ./web/src/helpers/api.pkce.test.js`: 11 passed, zero failed.
  These tests execute the actual helper bodies with HTTP/browser stubs and cover
  logout failures, authorization errors, absence of fallback, and legacy behavior.
- Independent review found no blocking issue. `git diff --check` passed.
- Full-file Prettier check reports existing formatting issues in both the pristine
  `api.js` and candidate. Unrelated upstream formatting was not rewritten.
  React Doctor is not installed/pinned in this project and was not downloaded.
- Go race detection was not run: the local Windows environment has no C compiler.
  The store tests exercise concurrent issuance and single-use consumption.

The Linux amd64 candidate was cross-compiled locally with the upstream build flags,
plus an explicit candidate version and without the temporary archive Git baseline:

```sh
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 GOEXPERIMENT=greenteagc \
go build -buildvcs=false \
  -ldflags '-s -w -X github.com/QuantumNous/new-api/common.Version=v0.13.2-pkce.1' \
  -o new-api-linux-amd64
```

ELF64/x86-64 and embedded Go build metadata were checked. The official Dockerfile
also uses CGO=0 and installs the executable as `/new-api`. Its SQLite driver is
`github.com/glebarez/sqlite` with `modernc.org/sqlite`; no new native library was
introduced. This is build/source evidence, not a Linux-container runtime check.
The release owner must run the candidate container and real SSO smoke tests.

The handoff contains the patch and a complete source archive assembled from the
fixed upstream archive plus this patch (including the original Bun lockfile).
Keep the corresponding source available with any network deployment of this
modified AGPL application; retain the original notices and branding.
