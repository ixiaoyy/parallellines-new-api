package middleware

import (
	"context"
	"errors"
	"io"
	"mime"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	"github.com/gin-gonic/gin"
)

const chatOAuthIssuer = "https://pingxingxian.space/auth/oidc"
const chatOAuthUserInfoURL = chatOAuthIssuer + "/me"
const chatOAuthAudience = "parallellines-openwebui"
const chatOAuthIdentityKey = "verified_chat_oauth_relay_identity"

var errChatOAuthInvalid = errors.New("invalid Chat authorization")
var errChatOAuthUnavailable = errors.New("Chat identity verification unavailable")

// No discovery, caller-controlled URL, redirect, credential cache, or ID-token
// interpretation. The trusted issuer verifies its opaque access token and current
// main-site session on every request; the audience must be this Chat client.
var chatOAuthHTTPClient = &http.Client{
	Timeout:       5 * time.Second,
	CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse },
}

type chatOAuthClaims struct {
	Issuer     string `json:"iss"`
	Audience   string `json:"aud"`
	Subject    string `json:"sub"`
	Binding    string `json:"pl_binding"`
	AuthExpiry int64  `json:"pl_auth_exp"`
}

type chatOAuthIdentity struct{ userID, tokenID int }

func verifyChatOAuthToken(ctx context.Context, accessToken string) (*chatOAuthClaims, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, chatOAuthUserInfoURL, nil)
	if err != nil {
		return nil, errChatOAuthUnavailable
	}
	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("Accept", "application/json")
	resp, err := chatOAuthHTTPClient.Do(req)
	if err != nil {
		return nil, errChatOAuthUnavailable
	}
	defer resp.Body.Close()
	if resp.StatusCode == 401 || resp.StatusCode == 403 {
		return nil, errChatOAuthInvalid
	}
	if resp.StatusCode != 200 {
		return nil, errChatOAuthUnavailable
	}
	body, err := io.ReadAll(io.LimitReader(resp.Body, 16385))
	if err != nil || len(body) > 16384 {
		return nil, errChatOAuthUnavailable
	}
	var claims chatOAuthClaims
	if common.Unmarshal(body, &claims) != nil {
		return nil, errChatOAuthInvalid
	}
	if claims.Issuer != chatOAuthIssuer || claims.Audience != chatOAuthAudience ||
		claims.Subject == "" || len(claims.Subject) > 256 || strings.TrimSpace(claims.Subject) != claims.Subject ||
		claims.Binding == "" || len(claims.Binding) > 512 || strings.TrimSpace(claims.Binding) != claims.Binding ||
		claims.AuthExpiry <= time.Now().Unix() {
		return nil, errChatOAuthInvalid
	}
	return &claims, nil
}

func chatOAuthAbort(c *gin.Context, status int, message string) {
	c.AbortWithStatusJSON(status, gin.H{"error": gin.H{"message": message, "type": "chat_oauth_relay_error"}})
}

// ChatOAuthRelay is installed only on the three explicit adapter routes. Client
// headers, query parameters and cookies never select an account or relay key.
func ChatOAuthRelay(canonicalPath string) gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Header("Cache-Control", "no-store")
		if os.Getenv("CHAT_OAUTH_RELAY_ENABLED") != "true" {
			chatOAuthAbort(c, 404, "Chat OAuth relay is disabled")
			return
		}
		if c.Request.URL.RawQuery != "" || c.Request.URL.RawPath != "" {
			chatOAuthAbort(c, 400, "Query credentials and encoded adapter paths are not accepted")
			return
		}
		for _, header := range []string{"X-Api-Key", "X-Goog-Api-Key", "Sec-WebSocket-Protocol", "Mj-Api-Secret", "New-Api-User", "X-User-Id"} {
			if c.GetHeader(header) != "" {
				chatOAuthAbort(c, 400, "Alternate credentials and caller-selected identities are not accepted")
				return
			}
		}
		auth := c.Request.Header.Values("Authorization")
		if len(auth) != 1 || len(auth[0]) > 8192 {
			chatOAuthAbort(c, 401, "A Chat OAuth bearer token is required")
			return
		}
		parts := strings.Fields(auth[0])
		if len(parts) != 2 || !strings.EqualFold(parts[0], "Bearer") {
			chatOAuthAbort(c, 401, "A Chat OAuth bearer token is required")
			return
		}
		claims, err := verifyChatOAuthToken(c.Request.Context(), parts[1])
		if err != nil {
			status := 401
			if errors.Is(err, errChatOAuthUnavailable) {
				status = 503
			}
			chatOAuthAbort(c, status, err.Error())
			return
		}
		user, err := model.ResolveOAuthRelayUser(1, "pingxingxian", claims.Subject)
		if err != nil {
			chatOAuthAbort(c, 403, "An enabled existing main-site account binding is required")
			return
		}
		token, err := model.GetOrCreateOAuthRelayToken(user.Id)
		if err != nil {
			chatOAuthAbort(c, 403, "The internal Chat credential is unavailable or revoked")
			return
		}
		c.Set(chatOAuthIdentityKey, chatOAuthIdentity{userID: user.Id, tokenID: token.Id})
		// Replace, never append: the original OAuth bearer must not reach a model.
		c.Request.Header.Set("Authorization", "Bearer "+token.Key)
		c.Request.Header.Del("Cookie")
		for header := range c.Request.Header {
			if strings.HasPrefix(strings.ToLower(header), "x-openwebui-user-") {
				c.Request.Header.Del(header)
			}
		}
		c.Request.URL.Path = canonicalPath
		c.Request.URL.RawPath = ""
		c.Request.RequestURI = canonicalPath
		c.Next()
	}
}

// Internal credentials are unusable on ordinary relay/usage routes, even if a
// secret is accidentally obtained. This context is set only after UserInfo and
// the native binding have been checked on this request.
func internalOAuthRelayTokenAllowed(c *gin.Context, token *model.Token) bool {
	value, selected := c.Get(chatOAuthIdentityKey)
	if token.InternalPurpose == nil {
		return !selected
	}
	identity, ok := value.(chatOAuthIdentity)
	return selected && ok && *token.InternalPurpose == model.OAuthRelayTokenPurpose &&
		identity.userID == token.UserId && identity.tokenID == token.Id
}

func ChatOAuthRelayModelLimit() gin.HandlerFunc {
	return func(c *gin.Context) {
		contentType, _, err := mime.ParseMediaType(c.GetHeader("Content-Type"))
		if err != nil || contentType != "application/json" {
			chatOAuthAbort(c, 415, "A JSON model request is required")
			return
		}
		var request struct {
			Model string `json:"model"`
		}
		if common.UnmarshalBodyReusable(c, &request) != nil {
			chatOAuthAbort(c, 400, "A JSON model request is required")
			return
		}
		for _, allowed := range strings.Split(model.OAuthRelayModelLimits, ",") {
			if request.Model == allowed {
				c.Next()
				return
			}
		}
		chatOAuthAbort(c, 403, "This model is not available through Chat")
	}
}
