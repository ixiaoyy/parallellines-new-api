package middleware

import (
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/dto"
	"github.com/QuantumNous/new-api/i18n"
	"github.com/QuantumNous/new-api/model"
	relaycommon "github.com/QuantumNous/new-api/relay/common"
	"github.com/QuantumNous/new-api/service"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm/logger"
)

type chatOAuthRoundTrip func(*http.Request) (*http.Response, error)

func (f chatOAuthRoundTrip) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

func fixtureChatClaims(sub string) map[string]any {
	return map[string]any{"iss": chatOAuthIssuer, "aud": chatOAuthAudience, "sub": sub,
		"pl_binding": "synthetic-session-binding", "pl_auth_exp": time.Now().Unix() + 300}
}

func mockChatUserInfo(t *testing.T, responder func(*http.Request) (int, any)) {
	t.Helper()
	old := chatOAuthHTTPClient
	client := *old
	client.Transport = chatOAuthRoundTrip(func(r *http.Request) (*http.Response, error) {
		if r.URL.String() != chatOAuthUserInfoURL || r.Method != "GET" || r.Header.Get("Cookie") != "" {
			t.Error("identity request escaped the fixed UserInfo contract")
		}
		status, value := responder(r)
		body, err := common.Marshal(value)
		if err != nil {
			t.Fatal(err)
		}
		return &http.Response{StatusCode: status, Header: http.Header{"Content-Type": {"application/json"}},
			Body: io.NopCloser(strings.NewReader(string(body))), Request: r}, nil
	})
	chatOAuthHTTPClient = &client
	t.Cleanup(func() { chatOAuthHTTPClient = old })
}

func TestChatOAuthRelayClaimsFailClosed(t *testing.T) {
	for _, tc := range []struct {
		name   string
		change func(map[string]any)
	}{
		{"wrong issuer", func(c map[string]any) { c["iss"] = "https://other.example" }},
		{"legacy audience", func(c map[string]any) { c["aud"] = "legacy-client" }},
		{"NewAPI audience", func(c map[string]any) { c["aud"] = "parallellines-newapi" }},
		{"audience array", func(c map[string]any) { c["aud"] = []string{chatOAuthAudience} }},
		{"missing subject", func(c map[string]any) { delete(c, "sub") }},
		{"normalized subject", func(c map[string]any) { c["sub"] = " fixture-a" }},
		{"missing binding", func(c map[string]any) { delete(c, "pl_binding") }},
		{"expired", func(c map[string]any) { c["pl_auth_exp"] = time.Now().Unix() - 1 }},
		{"string expiry", func(c map[string]any) { c["pl_auth_exp"] = "9999999999" }},
	} {
		t.Run(tc.name, func(t *testing.T) {
			claims := fixtureChatClaims("fixture-a")
			tc.change(claims)
			mockChatUserInfo(t, func(*http.Request) (int, any) { return 200, claims })
			if _, err := verifyChatOAuthToken(context.Background(), "synthetic-oauth-token"); err == nil {
				t.Fatal("invalid identity accepted")
			}
		})
	}
	t.Run("valid", func(t *testing.T) {
		mockChatUserInfo(t, func(*http.Request) (int, any) { return 200, fixtureChatClaims("fixture-a") })
		if _, err := verifyChatOAuthToken(context.Background(), "synthetic-oauth-token"); err != nil {
			t.Fatal(err)
		}
	})
	t.Run("oversized", func(t *testing.T) {
		claims := fixtureChatClaims("fixture-a")
		claims["extra"] = strings.Repeat("x", 16384)
		mockChatUserInfo(t, func(*http.Request) (int, any) { return 200, claims })
		if _, err := verifyChatOAuthToken(context.Background(), "synthetic-oauth-token"); err == nil {
			t.Fatal("oversized response accepted")
		}
	})
	t.Run("redirect refused", func(t *testing.T) {
		old := chatOAuthHTTPClient
		client := *old
		calls := 0
		client.Transport = chatOAuthRoundTrip(func(r *http.Request) (*http.Response, error) {
			calls++
			return &http.Response{StatusCode: 302, Header: http.Header{"Location": {"https://untrusted.example/me"}}, Body: http.NoBody, Request: r}, nil
		})
		chatOAuthHTTPClient = &client
		t.Cleanup(func() { chatOAuthHTTPClient = old })
		if _, err := verifyChatOAuthToken(context.Background(), "synthetic-oauth-token"); err == nil || calls != 1 {
			t.Fatal("UserInfo redirect followed")
		}
	})
}

func setupChatOAuthDB(t *testing.T) {
	t.Helper()
	gin.SetMode(gin.TestMode)
	if err := i18n.Init(); err != nil {
		t.Fatal(err)
	}
	oldDB, oldPath, oldMaster := model.DB, common.SQLitePath, common.IsMasterNode
	oldRedis, oldBatch := common.RedisEnabled, common.BatchUpdateEnabled
	t.Setenv("SQL_DSN", "local")
	t.Setenv("SQL_MAX_OPEN_CONNS", "1")
	t.Setenv("CHAT_OAUTH_RELAY_ENABLED", "true")
	common.SQLitePath = "file:chat-oauth-" + t.Name() + "?mode=memory&cache=shared"
	common.IsMasterNode, common.RedisEnabled, common.BatchUpdateEnabled = false, false, false
	if err := model.InitDB(); err != nil {
		t.Fatal(err)
	}
	model.DB.Logger = logger.Default.LogMode(logger.Silent)
	if err := model.DB.AutoMigrate(&model.User{}, &model.Token{}, &model.CustomOAuthProvider{}, &model.UserOAuthBinding{}); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		sqlDB, _ := model.DB.DB()
		_ = sqlDB.Close()
		model.DB, common.SQLitePath, common.IsMasterNode = oldDB, oldPath, oldMaster
		common.RedisEnabled, common.BatchUpdateEnabled = oldRedis, oldBatch
	})
	provider := model.CustomOAuthProvider{Id: 1, Slug: "pingxingxian", Name: "fixture", Enabled: true, UserIdField: "sub", UserInfoEndpoint: chatOAuthUserInfoURL}
	if err := model.DB.Create(&provider).Error; err != nil {
		t.Fatal(err)
	}
	for i, sub := range []string{"fixture-a", "fixture-b", "fixture-zero"} {
		quota := 100
		if i == 2 {
			quota = 0
		}
		user := model.User{Id: 101 + i, Username: sub, AffCode: sub, Role: common.RoleCommonUser, Status: common.UserStatusEnabled, Group: "default", Quota: quota}
		if err := model.DB.Create(&user).Error; err != nil {
			t.Fatal(err)
		}
		binding := model.UserOAuthBinding{UserId: user.Id, ProviderId: 1, ProviderUserId: sub}
		if err := model.DB.Create(&binding).Error; err != nil {
			t.Fatal(err)
		}
	}
}

func TestChatOAuthRelayNativeIdentityAndQuotaIsolation(t *testing.T) {
	setupChatOAuthDB(t)
	userinfoCalls := 0
	mockChatUserInfo(t, func(r *http.Request) (int, any) {
		userinfoCalls++
		sub := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer oauth-")
		if !strings.HasPrefix(sub, "fixture-") {
			return 401, map[string]any{"error": "invalid_token"}
		}
		return 200, fixtureChatClaims(sub)
	})
	r := gin.New()
	r.Use(BodyStorageCleanup())
	tokens := map[int]int{}
	seenPaths := map[string]int{}
	terminal := func(c *gin.Context) {
		uid, tid := c.GetInt("id"), c.GetInt("token_id")
		if old := tokens[uid]; old != 0 && old != tid {
			t.Error("credential not reused for same owner")
		}
		tokens[uid] = tid
		seenPaths[c.Request.URL.Path]++
		if strings.Contains(c.GetHeader("Authorization"), "oauth-") || c.GetHeader("Cookie") != "" {
			t.Error("source credentials survived mapping")
		}
		if c.Request.Method == "POST" {
			info := &relaycommon.RelayInfo{UserId: uid, TokenId: tid, TokenKey: c.GetString("token_key"), TokenUnlimited: c.GetBool("token_unlimited_quota"), UserSetting: dto.UserSetting{BillingPreference: "wallet_only"}}
			billing, apiErr := service.NewBillingSession(c, info, 10)
			if apiErr != nil {
				c.Status(apiErr.StatusCode)
				return
			}
			if err := billing.Settle(7); err != nil {
				t.Fatal(err)
			}
		}
		c.JSON(200, gin.H{"ok": true})
	}
	r.GET("/oauth-relay/v1/models", ChatOAuthRelay("/v1/models"), TokenAuth(), terminal)
	r.POST("/oauth-relay/v1/chat/completions", ChatOAuthRelay("/v1/chat/completions"), TokenAuth(), ChatOAuthRelayModelLimit(), terminal)
	r.POST("/oauth-relay/v1/responses", ChatOAuthRelay("/v1/responses"), TokenAuth(), ChatOAuthRelayModelLimit(), terminal)
	r.GET("/v1/models", TokenAuth(), terminal)
	r.GET("/usage", TokenAuthReadOnly(), terminal)
	request := func(method, path, bearer string, headers map[string]string, body string) int {
		req := httptest.NewRequest(method, path, strings.NewReader(body))
		if bearer != "" {
			req.Header.Set("Authorization", "Bearer "+bearer)
		}
		req.Header.Set("Content-Type", "application/json")
		for k, v := range headers {
			req.Header.Set(k, v)
		}
		w := httptest.NewRecorder()
		r.ServeHTTP(w, req)
		// The public test responses must never contain any persisted relay key.
		var internal []model.Token
		model.DB.Where("internal_purpose IS NOT NULL").Find(&internal)
		for _, key := range internal {
			if strings.Contains(w.Body.String(), key.Key) {
				t.Fatal("relay key exposed in response")
			}
		}
		return w.Code
	}
	for _, sub := range []string{"fixture-a", "fixture-b", "fixture-zero"} {
		if status := request("GET", "/oauth-relay/v1/models", "oauth-"+sub, nil, ""); status != 200 {
			t.Fatalf("free discovery status %d", status)
		}
	}
	body := `{"model":"gpt-6-luna","messages":[{"role":"user","content":[{"type":"text","text":"fixture"},{"type":"image_url","image_url":{"url":"data:image/png;base64,fixture"}}]}]}`
	for _, path := range []string{"/oauth-relay/v1/chat/completions", "/oauth-relay/v1/responses"} {
		if status := request("POST", path, "oauth-fixture-a", nil, body); status != 200 {
			t.Fatalf("native billing status %d", status)
		}
	}
	if tokens[101] == 0 || tokens[101] == tokens[102] || tokens[102] == tokens[103] {
		t.Fatal("different users shared an internal credential")
	}
	for uid, want := range map[int]int{101: 86, 102: 100, 103: 0} {
		user, err := model.GetUserById(uid, false)
		if err != nil || user.Quota != want {
			t.Fatalf("user %d quota changed incorrectly", uid)
		}
	}
	if status := request("POST", "/oauth-relay/v1/responses", "oauth-fixture-zero", nil, body); status != 403 {
		t.Fatalf("zero quota was not rejected: %d", status)
	}
	if seenPaths["/v1/models"] != 3 || seenPaths["/v1/chat/completions"] != 1 || seenPaths["/v1/responses"] != 2 {
		t.Fatal("canonical paths not preserved")
	}
	for _, h := range []string{"X-Api-Key", "X-Goog-Api-Key", "Sec-WebSocket-Protocol", "Mj-Api-Secret", "New-Api-User", "X-User-Id"} {
		before := userinfoCalls
		if status := request("GET", "/oauth-relay/v1/models", "oauth-fixture-a", map[string]string{h: "spoof"}, ""); status != 400 || userinfoCalls != before {
			t.Fatal("alternate credential header accepted")
		}
	}
	if status := request("GET", "/oauth-relay/v1/models?key=spoof", "oauth-fixture-a", nil, ""); status != 400 {
		t.Fatal("query accepted")
	}
	if status := request("GET", "/oauth-relay/v1/models", "", nil, ""); status != 401 {
		t.Fatal("anonymous request accepted")
	}
	if status := request("GET", "/oauth-relay/v1/models", "oauth-fixture-missing", nil, ""); status != 403 {
		t.Fatal("missing native binding accepted")
	}
	if status := request("POST", "/oauth-relay/v1/responses", "oauth-fixture-a", nil, `{"model":"gpt-6-luna-thinking"}`); status != 403 {
		t.Fatal("nonexact model accepted")
	}
	internal, err := model.GetOrCreateOAuthRelayToken(101)
	if err != nil {
		t.Fatal(err)
	}
	for _, path := range []string{"/v1/models", "/usage"} {
		if request("GET", path, internal.Key, nil, "") != 401 {
			t.Fatal("internal key accepted outside verified adapter")
		}
	}
	if err := model.RevokeOAuthRelayToken(101); err != nil {
		t.Fatal(err)
	}
	if request("GET", "/oauth-relay/v1/models", "oauth-fixture-a", nil, "") != 403 {
		t.Fatal("revoked internal key was renewed")
	}
	model.DB.Model(&model.User{}).Where("id = ?", 102).Update("status", common.UserStatusDisabled)
	if request("GET", "/oauth-relay/v1/models", "oauth-fixture-b", nil, "") != 403 {
		t.Fatal("disabled user accepted")
	}
}
