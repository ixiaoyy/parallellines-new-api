package middleware

import (
	"errors"
	"net/http"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/i18n"
	"github.com/QuantumNous/new-api/model"
	"github.com/gin-contrib/sessions"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

var errCookieIdentityInvalid = errors.New("invalid login session")
var errCookieIdentityDatabase = errors.New("login session lookup unavailable")

// Check only account existence. All existing cookie authorization claims keep
// their native meaning; anonymous and OAuth state-only cookies need no DB read.
func checkCookieUserExists(c *gin.Context) error {
	session := sessions.Default(c)
	rawID := session.Get("id")
	if rawID == nil {
		return nil
	}
	id, ok := rawID.(int)
	if !ok || id <= 0 {
		return errCookieIdentityInvalid
	}
	err := model.CheckSessionUserExists(id)
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return errCookieIdentityInvalid
	}
	if err != nil {
		return errCookieIdentityDatabase
	}
	return nil
}

func clearInvalidLoginCookie(c *gin.Context) {
	session := sessions.Default(c)
	session.Clear()
	// Clearing this browser is a convenience; replay is rejected by the DB check
	// even if saving fails or a caller retains the original signed cookie.
	_ = session.Save()
}

func rejectCookieIdentity(c *gin.Context, err error) {
	if errors.Is(err, errCookieIdentityDatabase) {
		c.AbortWithStatusJSON(http.StatusServiceUnavailable, gin.H{"success": false, "message": common.TranslateMessage(c, i18n.MsgDatabaseError)})
		return
	}
	clearInvalidLoginCookie(c)
	c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"success": false, "message": common.TranslateMessage(c, i18n.MsgAuthNotLoggedIn)})
}
