package middleware

import (
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/i18n"
	"github.com/QuantumNous/new-api/model"
	"github.com/gin-contrib/sessions"
	"github.com/gin-contrib/sessions/cookie"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

func sessionRevocationFixture(t *testing.T) *gin.Engine {
	t.Helper()
	gin.SetMode(gin.TestMode)
	require.NoError(t, i18n.Init())
	oldDB, oldPath, oldMaster := model.DB, common.SQLitePath, common.IsMasterNode
	oldRedis, oldBatch := common.RedisEnabled, common.BatchUpdateEnabled
	oldSQLite, oldMySQL, oldPostgres := common.UsingSQLite, common.UsingMySQL, common.UsingPostgreSQL
	t.Setenv("SQL_DSN", "local")
	t.Setenv("SQL_MAX_OPEN_CONNS", "1")
	common.SQLitePath = ":memory:"
	common.IsMasterNode, common.RedisEnabled, common.BatchUpdateEnabled = false, false, false
	common.UsingMySQL, common.UsingPostgreSQL = false, false
	require.NoError(t, model.InitDB())
	db := model.DB
	db.Logger = logger.Default.LogMode(logger.Silent)
	t.Cleanup(func() {
		sqlDB, _ := db.DB()
		_ = sqlDB.Close()
		model.DB, common.SQLitePath, common.IsMasterNode = oldDB, oldPath, oldMaster
		common.RedisEnabled, common.BatchUpdateEnabled = oldRedis, oldBatch
		common.UsingSQLite, common.UsingMySQL, common.UsingPostgreSQL = oldSQLite, oldMySQL, oldPostgres
	})
	require.NoError(t, db.AutoMigrate(&model.User{}, &model.Token{}))
	access := "synthetic-management-access"
	require.NoError(t, db.Create(&model.User{Id: 1, Username: "synthetic-root", Role: common.RoleRootUser, Status: common.UserStatusEnabled, Group: "default", AffCode: "fixture-one"}).Error)
	require.NoError(t, db.Create(&model.User{Id: 2, Username: "synthetic-user", Role: common.RoleCommonUser, Status: common.UserStatusEnabled, Group: "default", AffCode: "fixture-two", AccessToken: &access}).Error)
	require.NoError(t, db.Create(&model.Token{UserId: 2, Key: "syntheticrelaykey", Status: common.TokenStatusEnabled, ExpiredTime: -1, RemainQuota: 10}).Error)
	r := gin.New()
	store := cookie.NewStore([]byte("synthetic-cookie-signing-key-32-bytes"))
	store.Options(sessions.Options{Path: "/", HttpOnly: true, MaxAge: 2592000})
	r.Use(sessions.Sessions("session", store))
	probe := func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"handler": true, "id": c.GetInt("id"), "role": c.GetInt("role"), "username": c.GetString("username"), "group": c.GetString("group"), "token_id": c.GetInt("token_id"), "access": c.GetBool("use_access_token")})
	}
	r.GET("/root", RootAuth(), probe)
	r.GET("/admin", AdminAuth(), probe)
	r.GET("/user", UserAuth(), probe)
	r.GET("/video", TokenOrUserAuth(), probe)
	r.GET("/pricing", TryUserAuth(), probe)
	return r
}

func sessionRevocationCookie(t *testing.T, r *gin.Engine, values map[string]any) *http.Cookie {
	t.Helper()
	// Sign with the real store implementation, not a mocked middleware identity.
	r.GET("/fixture-sign", func(c *gin.Context) {
		session := sessions.Default(c)
		for key, value := range values {
			session.Set(key, value)
		}
		require.NoError(t, session.Save())
		c.Status(http.StatusNoContent)
	})
	w := httptest.NewRecorder()
	r.ServeHTTP(w, httptest.NewRequest(http.MethodGet, "/fixture-sign", nil))
	require.NotEmpty(t, w.Result().Cookies())
	return w.Result().Cookies()[0]
}

func sessionRevocationRequest(r *gin.Engine, path string, login *http.Cookie, bearer, userID string) *httptest.ResponseRecorder {
	w := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, path, nil)
	if login != nil {
		req.AddCookie(login)
	}
	if bearer != "" {
		req.Header.Set("Authorization", "Bearer "+bearer)
	}
	if userID != "" {
		req.Header.Set("New-Api-User", userID)
	}
	r.ServeHTTP(w, req)
	return w
}

func sessionRevocationRootClaims() map[string]any {
	return map[string]any{"id": 1, "username": "synthetic-root", "role": common.RoleRootUser, "status": common.UserStatusEnabled, "group": "old-cookie-group"}
}

func TestSessionRevocationDeletedCookieCannotReplay(t *testing.T) {
	for _, change := range []string{"hard-delete", "soft-delete"} {
		t.Run(change, func(t *testing.T) {
			r := sessionRevocationFixture(t)
			login := sessionRevocationCookie(t, r, sessionRevocationRootClaims())
			require.Contains(t, sessionRevocationRequest(r, "/root", login, "", "1").Body.String(), `"handler":true`)
			var err error
			switch change {
			case "hard-delete":
				err = model.DB.Unscoped().Delete(&model.User{}, 1).Error
			case "soft-delete":
				err = model.DB.Delete(&model.User{}, 1).Error
			}
			require.NoError(t, err)
			for _, path := range []string{"/root", "/admin", "/user", "/video"} {
				// Keep replaying the original cookie, ignoring any browser-clearing response.
				for replay := 0; replay < 2; replay++ {
					w := sessionRevocationRequest(r, path, login, "syntheticrelaykey", "1")
					require.Equal(t, http.StatusUnauthorized, w.Code)
					require.NotContains(t, w.Body.String(), `"handler":true`)
				}
			}
			w := sessionRevocationRequest(r, "/pricing", login, "", "")
			require.Equal(t, http.StatusOK, w.Code)
			require.Contains(t, w.Body.String(), `"id":0`)
		})
	}
}

func TestSessionRevocationPreservesExistingCookieClaims(t *testing.T) {
	r := sessionRevocationFixture(t)
	login := sessionRevocationCookie(t, r, sessionRevocationRootClaims())
	// The approved scope is deletion only. Changes to an existing row's claims
	// intentionally retain the native cookie semantics in this increment.
	require.NoError(t, model.DB.Model(&model.User{}).Where("id = ?", 1).Updates(map[string]any{"role": common.RoleCommonUser, "status": common.UserStatusDisabled, "username": "renamed-user", "group": "new-group"}).Error)
	for _, path := range []string{"/root", "/admin", "/user"} {
		w := sessionRevocationRequest(r, path, login, "", "1")
		require.Equal(t, http.StatusOK, w.Code)
		require.Contains(t, w.Body.String(), `"id":1`)
		require.Contains(t, w.Body.String(), `"role":100`)
		require.Contains(t, w.Body.String(), `"username":"synthetic-root"`)
		require.Contains(t, w.Body.String(), `"group":"old-cookie-group"`)
	}
	for _, path := range []string{"/video", "/pricing"} {
		w := sessionRevocationRequest(r, path, login, "", "")
		require.Equal(t, http.StatusOK, w.Code)
		require.Contains(t, w.Body.String(), `"id":1`)
		require.Contains(t, w.Body.String(), `"role":0`)
	}
	w := sessionRevocationRequest(r, "/user", login, "", "2")
	require.Equal(t, http.StatusUnauthorized, w.Code)
	require.NotContains(t, w.Body.String(), `"handler":true`)
}

func TestSessionRevocationDatabaseFailureIsClosedAndSanitized(t *testing.T) {
	r := sessionRevocationFixture(t)
	login := sessionRevocationCookie(t, r, sessionRevocationRootClaims())
	require.NoError(t, model.DB.Callback().Query().Before("gorm:query").Register("session_failure", func(tx *gorm.DB) { tx.AddError(errors.New("synthetic-private-db-detail")) }))
	for _, path := range []string{"/root", "/video", "/pricing"} {
		w := sessionRevocationRequest(r, path, login, "", "1")
		require.Equal(t, http.StatusServiceUnavailable, w.Code)
		require.NotContains(t, w.Body.String(), "synthetic-private-db-detail")
		require.NotContains(t, w.Body.String(), `"handler":true`)
	}
	// No identity means no authorization DB read, even if the database is down.
	w := sessionRevocationRequest(r, "/pricing", nil, "", "")
	require.Equal(t, http.StatusOK, w.Code)
	require.Contains(t, w.Body.String(), `"id":0`)
}

func TestSessionRevocationAnonymousAndBearerPaths(t *testing.T) {
	r := sessionRevocationFixture(t)
	state := sessionRevocationCookie(t, r, map[string]any{"oauth_state": "synthetic-state", "aff": "synthetic-aff"})
	w := sessionRevocationRequest(r, "/pricing", state, "", "")
	require.Equal(t, http.StatusOK, w.Code)
	require.Empty(t, w.Result().Cookies(), "OAuth state-only cookie must not be cleared")
	w = sessionRevocationRequest(r, "/user", nil, "synthetic-management-access", "2")
	require.Equal(t, http.StatusOK, w.Code)
	require.Contains(t, w.Body.String(), `"id":2`)
	require.Contains(t, w.Body.String(), `"access":true`)
	w = sessionRevocationRequest(r, "/video", nil, "syntheticrelaykey", "")
	require.Equal(t, http.StatusOK, w.Code)
	require.Contains(t, w.Body.String(), `"id":2`)
	require.NotContains(t, w.Body.String(), `"token_id":0`)
}
