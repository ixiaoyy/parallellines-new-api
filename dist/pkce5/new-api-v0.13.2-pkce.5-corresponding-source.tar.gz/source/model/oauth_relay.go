package model

import (
	"errors"
	"fmt"
	"strings"

	"github.com/QuantumNous/new-api/common"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
	"gorm.io/gorm/logger"
)

const OAuthRelayTokenPurpose = "chat-oauth-v1"
const OAuthRelayModelLimits = "gpt-6-luna,gpt-6.1-terra,gpt-6.1-sol"
const OAuthRelayUserInfoURL = "https://pingxingxian.space/auth/oidc/me"

var (
	ErrOAuthRelayIdentityDenied        = errors.New("OAuth relay identity is not bound to an active user")
	ErrOAuthRelayCredentialUnavailable = errors.New("OAuth relay credential is unavailable")
)

// Internal credentials never enter the ordinary token-management surface, even
// when the caller owns their billing account. NULL preserves all upstream tokens.
func userManagedTokens(db *gorm.DB) *gorm.DB {
	return db.Where("internal_purpose IS NULL")
}

func activeOAuthRelayRole(user *User) bool {
	return user.Status == common.UserStatusEnabled && !user.DeletedAt.Valid &&
		(user.Role == common.RoleCommonUser || user.Role == common.RoleAdminUser || user.Role == common.RoleRootUser)
}

func validOAuthRelayKey(key string) bool {
	if len(key) != 48 {
		return false
	}
	for _, c := range key {
		if !((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) {
			return false
		}
	}
	return true
}

// ResolveOAuthRelayUser accepts only an existing native provider/sub binding.
// User creation, email matching, role changes and quota grants are intentionally
// absent. Read the database on every resolution so binding/status changes are not
// hidden by a cached OAuth identity or an old login session.
func ResolveOAuthRelayUser(providerID int, slug string, sub string) (*User, error) {
	if providerID <= 0 || slug == "" || sub == "" || strings.TrimSpace(sub) != sub {
		return nil, ErrOAuthRelayIdentityDenied
	}
	var provider CustomOAuthProvider
	if err := DB.First(&provider, "id = ?", providerID).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrOAuthRelayIdentityDenied
		}
		return nil, fmt.Errorf("%w: OAuth provider lookup failed", ErrDatabase)
	}
	if !provider.Enabled || provider.Slug != slug || provider.UserIdField != "sub" || provider.UserInfoEndpoint != OAuthRelayUserInfoURL {
		return nil, ErrOAuthRelayIdentityDenied
	}
	var bindings []UserOAuthBinding
	if err := DB.Where("provider_id = ? AND provider_user_id = ?", providerID, sub).Limit(2).Find(&bindings).Error; err != nil {
		return nil, fmt.Errorf("%w: OAuth binding lookup failed", ErrDatabase)
	}
	// Some MySQL installations use case-insensitive VARCHAR collations. OAuth
	// subjects are opaque, case-sensitive identifiers regardless of DB collation.
	if len(bindings) != 1 || bindings[0].ProviderId != providerID || bindings[0].ProviderUserId != sub {
		return nil, ErrOAuthRelayIdentityDenied
	}
	user, err := GetUserById(bindings[0].UserId, false)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrOAuthRelayIdentityDenied
		}
		return nil, fmt.Errorf("%w: OAuth user lookup failed", ErrDatabase)
	}
	if !activeOAuthRelayRole(user) {
		return nil, ErrOAuthRelayIdentityDenied
	}
	return user, nil
}

func loadOAuthRelayToken(userID int) (*Token, error) {
	var token Token
	err := DB.Unscoped().Where("user_id = ? AND internal_purpose = ?", userID, OAuthRelayTokenPurpose).First(&token).Error
	if err != nil {
		return nil, err
	}
	if token.UserId != userID || token.InternalPurpose == nil || *token.InternalPurpose != OAuthRelayTokenPurpose ||
		token.DeletedAt.Valid || token.Status != common.TokenStatusEnabled || token.ExpiredTime != -1 ||
		!validOAuthRelayKey(token.Key) || !token.UnlimitedQuota || !token.ModelLimitsEnabled || token.ModelLimits != OAuthRelayModelLimits ||
		token.Group != "" || token.CrossGroupRetry || (token.AllowIps != nil && *token.AllowIps != "") {
		return nil, ErrOAuthRelayCredentialUnavailable
	}
	return &token, nil
}

// GetOrCreateOAuthRelayToken creates one server-only credential per existing user.
// The nullable-purpose unique index keeps ordinary NULL-purpose tokens unlimited
// in number while making concurrent internal issuance single-winner on all three
// supported databases. Disabled/expired/soft-deleted credentials are never renewed.
// UnlimitedQuota removes only a redundant token budget; the unchanged relay
// pipeline continues to enforce and settle the user's own wallet/subscription.
func GetOrCreateOAuthRelayToken(userID int) (*Token, error) {
	if userID <= 0 {
		return nil, ErrOAuthRelayIdentityDenied
	}
	user, err := GetUserById(userID, false)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrOAuthRelayIdentityDenied
		}
		return nil, fmt.Errorf("%w: OAuth user lookup failed", ErrDatabase)
	}
	if !activeOAuthRelayRole(user) {
		return nil, ErrOAuthRelayIdentityDenied
	}
	token, err := loadOAuthRelayToken(userID)
	if err == nil || errors.Is(err, ErrOAuthRelayCredentialUnavailable) {
		return token, err
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, fmt.Errorf("%w: OAuth credential lookup failed", ErrDatabase)
	}
	key, err := common.GenerateKey()
	if err != nil {
		return nil, ErrOAuthRelayCredentialUnavailable
	}
	purpose := OAuthRelayTokenPurpose
	token = &Token{
		UserId: userID, InternalPurpose: &purpose, Key: key,
		Name: "Chat OAuth internal", Status: common.TokenStatusEnabled,
		CreatedTime: common.GetTimestamp(), AccessedTime: common.GetTimestamp(), ExpiredTime: -1,
		RemainQuota: 0, UnlimitedQuota: true, ModelLimitsEnabled: true, ModelLimits: OAuthRelayModelLimits,
	}
	if err := DB.Session(&gorm.Session{Logger: DB.Logger.LogMode(logger.Silent)}).
		Clauses(clause.OnConflict{DoNothing: true}).Create(token).Error; err != nil {
		// Do not include driver/SQL details: some drivers interpolate credential keys.
		return nil, fmt.Errorf("%w: OAuth credential creation failed", ErrDatabase)
	}
	// Always load the unique winner rather than returning an uncommitted candidate.
	token, err = loadOAuthRelayToken(userID)
	if err != nil {
		if errors.Is(err, ErrOAuthRelayCredentialUnavailable) {
			return nil, err
		}
		return nil, fmt.Errorf("%w: OAuth credential lookup failed", ErrDatabase)
	}
	return token, nil
}

// RevokeOAuthRelayToken disables an already issued internal credential. A missing
// row is reported, not treated as a durable ban on future issuance. Revocation is
// idempotent; retrieval never recreates or enables a disabled/deleted credential.
func RevokeOAuthRelayToken(userID int) error {
	if userID <= 0 {
		return gorm.ErrRecordNotFound
	}
	var token Token
	err := DB.Unscoped().Where("user_id = ? AND internal_purpose = ?", userID, OAuthRelayTokenPurpose).First(&token).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return gorm.ErrRecordNotFound
		}
		return fmt.Errorf("%w: OAuth credential lookup failed", ErrDatabase)
	}
	if token.InternalPurpose == nil || *token.InternalPurpose != OAuthRelayTokenPurpose {
		return ErrOAuthRelayCredentialUnavailable
	}
	if err := DB.Unscoped().Model(&Token{}).Where("id = ? AND user_id = ?", token.Id, userID).
		Update("status", common.TokenStatusDisabled).Error; err != nil {
		return fmt.Errorf("%w: OAuth credential revocation failed", ErrDatabase)
	}
	if common.RedisEnabled {
		if err := cacheDeleteToken(token.Key); err != nil {
			return fmt.Errorf("%w: OAuth credential cache invalidation failed", ErrDatabase)
		}
	}
	return nil
}
