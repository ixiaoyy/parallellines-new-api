package model

import (
	"errors"
	"fmt"
	"strings"
	"sync"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/glebarez/sqlite"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

func oauthRelayTestDB(t *testing.T) *gorm.DB {
	t.Helper()
	oldDB, oldRedis := DB, common.RedisEnabled
	oldKeyCol, oldGroupCol := commonKeyCol, commonGroupCol
	dsn := "file:oauth_relay_" + strings.ReplaceAll(t.Name(), "/", "_") + "?mode=memory&cache=shared"
	db, err := gorm.Open(sqlite.Open(dsn), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatal(err)
	}
	sqlDB, err := db.DB()
	if err != nil {
		t.Fatal(err)
	}
	sqlDB.SetMaxOpenConns(1)
	sqlDB.SetMaxIdleConns(1)
	DB, common.RedisEnabled = db, false
	commonKeyCol, commonGroupCol = "`key`", "`group`"
	t.Cleanup(func() {
		DB, common.RedisEnabled = oldDB, oldRedis
		commonKeyCol, commonGroupCol = oldKeyCol, oldGroupCol
		_ = sqlDB.Close()
	})
	if err := db.AutoMigrate(&User{}, &CustomOAuthProvider{}, &UserOAuthBinding{}, &Token{}); err != nil {
		t.Fatal(err)
	}
	return db
}

func oauthRelayFixture(t *testing.T, db *gorm.DB, userID int, sub string) *User {
	t.Helper()
	user := &User{
		Id: userID, Username: fmt.Sprintf("relay-fixture-%d", userID), AffCode: fmt.Sprintf("relay-aff-%d", userID),
		Role: common.RoleCommonUser, Status: common.UserStatusEnabled, Group: "default", Quota: 1000 + userID,
	}
	if err := db.Create(user).Error; err != nil {
		t.Fatal(err)
	}
	var count int64
	if err := db.Model(&CustomOAuthProvider{}).Where("id = ?", 1).Count(&count).Error; err != nil {
		t.Fatal(err)
	}
	if count == 0 {
		provider := &CustomOAuthProvider{Id: 1, Slug: "pingxingxian", Name: "Fixture", Enabled: true, UserIdField: "sub", UserInfoEndpoint: OAuthRelayUserInfoURL}
		if err := db.Create(provider).Error; err != nil {
			t.Fatal(err)
		}
	}
	if err := db.Create(&UserOAuthBinding{UserId: userID, ProviderId: 1, ProviderUserId: sub}).Error; err != nil {
		t.Fatal(err)
	}
	return user
}

func oauthRelayNormalToken(t *testing.T, userID int, name string) *Token {
	t.Helper()
	key, err := common.GenerateKey()
	if err != nil {
		t.Fatal("failed to generate fixture token")
	}
	token := &Token{UserId: userID, Key: key, Name: name, Status: common.TokenStatusEnabled, ExpiredTime: -1, UnlimitedQuota: true}
	if err := token.Insert(); err != nil {
		t.Fatal(err)
	}
	return token
}

type oauthRelayLegacyToken struct {
	Id     int
	UserId int    `gorm:"index"`
	Key    string `gorm:"type:varchar(128);uniqueIndex"`
	Status int    `gorm:"default:1"`
}

func (oauthRelayLegacyToken) TableName() string { return "tokens" }

func TestOAuthRelayMigratesLegacyTokensWithoutClaimingThem(t *testing.T) {
	db := oauthRelayTestDB(t)
	user := oauthRelayFixture(t, db, 11, "stable-sub-A")
	if err := db.Migrator().DropTable(&Token{}); err != nil {
		t.Fatal(err)
	}
	if err := db.AutoMigrate(&oauthRelayLegacyToken{}); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 2; i++ {
		key, err := common.GenerateKey()
		if err != nil {
			t.Fatal("fixture credential generation failed")
		}
		if err := db.Create(&oauthRelayLegacyToken{UserId: user.Id, Key: key, Status: common.TokenStatusEnabled}).Error; err != nil {
			t.Fatal(err)
		}
	}
	if err := db.AutoMigrate(&Token{}); err != nil {
		t.Fatal(err)
	}
	if count, err := CountUserTokens(user.Id); err != nil || count != 2 {
		t.Fatal("migration did not preserve both existing NULL-purpose tokens")
	}
	internal, err := GetOrCreateOAuthRelayToken(user.Id)
	if err != nil {
		t.Fatal(err)
	}
	if err := db.AutoMigrate(&Token{}); err != nil {
		t.Fatal(err)
	}
	loaded, err := GetOrCreateOAuthRelayToken(user.Id)
	if err != nil || loaded.Id != internal.Id || loaded.Key != internal.Key {
		t.Fatal("repeated migration changed the issued internal credential")
	}
	if count, err := CountUserTokens(user.Id); err != nil || count != 2 {
		t.Fatal("migration exposed or consumed a normal token slot")
	}
}

func TestOAuthRelayResolveOnlyExistingExactActiveBinding(t *testing.T) {
	for _, role := range []int{common.RoleCommonUser, common.RoleAdminUser, common.RoleRootUser} {
		t.Run(fmt.Sprintf("role_%d", role), func(t *testing.T) {
			db := oauthRelayTestDB(t)
			user := oauthRelayFixture(t, db, 11, "stable-sub-A")
			if err := db.Model(user).Updates(map[string]any{"role": role, "quota": 0}).Error; err != nil {
				t.Fatal(err)
			}
			resolved, err := ResolveOAuthRelayUser(1, "pingxingxian", "stable-sub-A")
			if err != nil || resolved.Id != user.Id || resolved.Role != role || resolved.Quota != 0 {
				t.Fatal("existing active binding was not resolved without changing role/quota")
			}
		})
	}
	cases := []struct {
		name   string
		mutate func(*gorm.DB, *User) error
		id     int
		slug   string
		sub    string
	}{
		{"unknown_provider", nil, 2, "pingxingxian", "stable-sub-A"},
		{"wrong_slug", nil, 1, "another", "stable-sub-A"},
		{"missing_sub", nil, 1, "pingxingxian", ""},
		{"unknown_sub", nil, 1, "pingxingxian", "stable-sub-B"},
		{"case_changed_sub", nil, 1, "pingxingxian", "stable-sub-a"},
		{"disabled_provider", func(db *gorm.DB, _ *User) error {
			return db.Model(&CustomOAuthProvider{}).Where("id = ?", 1).Update("enabled", false).Error
		}, 1, "pingxingxian", "stable-sub-A"},
		{"non_sub_mapping", func(db *gorm.DB, _ *User) error {
			return db.Model(&CustomOAuthProvider{}).Where("id = ?", 1).Update("user_id_field", "email").Error
		}, 1, "pingxingxian", "stable-sub-A"},
		{"wrong_provider_issuer", func(db *gorm.DB, _ *User) error {
			return db.Model(&CustomOAuthProvider{}).Where("id = ?", 1).Update("user_info_endpoint", "https://other.example/me").Error
		}, 1, "pingxingxian", "stable-sub-A"},
		{"missing_binding", func(db *gorm.DB, _ *User) error {
			return db.Where("provider_id = ?", 1).Delete(&UserOAuthBinding{}).Error
		}, 1, "pingxingxian", "stable-sub-A"},
		{"disabled_user", func(db *gorm.DB, u *User) error { return db.Model(u).Update("status", common.UserStatusDisabled).Error }, 1, "pingxingxian", "stable-sub-A"},
		{"deleted_user", func(db *gorm.DB, u *User) error { return db.Delete(u).Error }, 1, "pingxingxian", "stable-sub-A"},
		{"guest_role", func(db *gorm.DB, u *User) error { return db.Model(u).Update("role", 0).Error }, 1, "pingxingxian", "stable-sub-A"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			db := oauthRelayTestDB(t)
			user := oauthRelayFixture(t, db, 11, "stable-sub-A")
			if tc.mutate != nil {
				if err := tc.mutate(db, user); err != nil {
					t.Fatal(err)
				}
			}
			resolved, err := ResolveOAuthRelayUser(tc.id, tc.slug, tc.sub)
			if resolved != nil || !errors.Is(err, ErrOAuthRelayIdentityDenied) {
				t.Fatal("invalid binding unexpectedly resolved")
			}
			var count int64
			if err := db.Model(&Token{}).Count(&count).Error; err != nil || count != 0 {
				t.Fatal("identity resolution created credentials")
			}
		})
	}
}

func TestOAuthRelayResolveRejectsAmbiguousBinding(t *testing.T) {
	db := oauthRelayTestDB(t)
	oauthRelayFixture(t, db, 11, "stable-sub-A")
	oauthRelayFixture(t, db, 12, "stable-sub-B")
	if err := db.Migrator().DropIndex(&UserOAuthBinding{}, "ux_provider_userid"); err != nil {
		t.Fatal(err)
	}
	if err := db.Model(&UserOAuthBinding{}).Where("user_id = ?", 12).Update("provider_user_id", "stable-sub-A").Error; err != nil {
		t.Fatal(err)
	}
	if user, err := ResolveOAuthRelayUser(1, "pingxingxian", "stable-sub-A"); user != nil || !errors.Is(err, ErrOAuthRelayIdentityDenied) {
		t.Fatal("ambiguous binding was accepted")
	}
}

func TestOAuthRelayCredentialsAreSeparateRestrictedAndStable(t *testing.T) {
	db := oauthRelayTestDB(t)
	a := oauthRelayFixture(t, db, 11, "stable-sub-A")
	b := oauthRelayFixture(t, db, 12, "stable-sub-B")
	ta, err := GetOrCreateOAuthRelayToken(a.Id)
	if err != nil {
		t.Fatal(err)
	}
	tb, err := GetOrCreateOAuthRelayToken(b.Id)
	if err != nil {
		t.Fatal(err)
	}
	if ta.Id == tb.Id || ta.Key == tb.Key || ta.UserId != a.Id || tb.UserId != b.Id {
		t.Fatal("two billing users shared a credential or owner")
	}
	for _, token := range []*Token{ta, tb} {
		if token.InternalPurpose == nil || *token.InternalPurpose != OAuthRelayTokenPurpose ||
			!token.ModelLimitsEnabled || token.ModelLimits != OAuthRelayModelLimits || !token.UnlimitedQuota ||
			token.RemainQuota != 0 || token.ExpiredTime != -1 || token.Group != "" || token.CrossGroupRetry {
			t.Fatal("internal credential is not restricted to the approved contract")
		}
	}
	if err := db.Model(&Token{}).Where("id = ?", ta.Id).Updates(map[string]any{"remain_quota": -20, "used_quota": 20}).Error; err != nil {
		t.Fatal(err)
	}
	loaded, err := GetOrCreateOAuthRelayToken(a.Id)
	if err != nil || loaded.Id != ta.Id || loaded.Key != ta.Key || loaded.UsedQuota != 20 {
		t.Fatal("normal usage accounting replaced the internal credential")
	}
	for _, original := range []*User{a, b} {
		current, err := GetUserById(original.Id, false)
		if err != nil || current.Quota != original.Quota || current.Role != original.Role {
			t.Fatal("credential issuance granted user quota or permissions")
		}
	}
}

func TestOAuthRelayCredentialConcurrentIssuanceAndNullableMigration(t *testing.T) {
	db := oauthRelayTestDB(t)
	user := oauthRelayFixture(t, db, 11, "stable-sub-A")
	normal1 := oauthRelayNormalToken(t, user.Id, "normal-one")
	normal2 := oauthRelayNormalToken(t, user.Id, "normal-two")
	if normal1.Id == normal2.Id {
		t.Fatal("NULL-purpose normal tokens collided")
	}
	const workers = 24
	start := make(chan struct{})
	ids, failures := make(chan int, workers), make(chan error, workers)
	var wg sync.WaitGroup
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			<-start
			token, err := GetOrCreateOAuthRelayToken(user.Id)
			if err != nil {
				failures <- err
				return
			}
			ids <- token.Id
		}()
	}
	close(start)
	wg.Wait()
	close(ids)
	close(failures)
	for err := range failures {
		t.Fatalf("concurrent issuance failed: %v", err)
	}
	winner, results := 0, 0
	for id := range ids {
		results++
		if winner == 0 {
			winner = id
		} else if id != winner {
			t.Fatal("concurrent issuance returned different credentials")
		}
	}
	var count int64
	if err := db.Model(&Token{}).Where("user_id = ? AND internal_purpose = ?", user.Id, OAuthRelayTokenPurpose).Count(&count).Error; err != nil || count != 1 || results != workers {
		t.Fatal("unique internal credential invariant failed")
	}
}

func TestOAuthRelayCredentialRefusesRevokedOrCorruptRows(t *testing.T) {
	cases := []struct {
		name   string
		mutate func(*gorm.DB, *Token) error
	}{
		{"disabled", func(db *gorm.DB, token *Token) error {
			return db.Model(token).Update("status", common.TokenStatusDisabled).Error
		}},
		{"expired", func(db *gorm.DB, token *Token) error {
			return db.Model(token).Update("expired_time", common.GetTimestamp()-1).Error
		}},
		{"deleted", func(db *gorm.DB, token *Token) error { return db.Delete(token).Error }},
		{"model_limits_disabled", func(db *gorm.DB, token *Token) error {
			return db.Model(token).Update("model_limits_enabled", false).Error
		}},
		{"extra_model", func(db *gorm.DB, token *Token) error {
			return db.Model(token).Update("model_limits", OAuthRelayModelLimits+",unapproved-model").Error
		}},
		{"group_override", func(db *gorm.DB, token *Token) error { return db.Model(token).Update("group", "vip").Error }},
		{"key_separator", func(db *gorm.DB, token *Token) error {
			return db.Model(token).Update("key", strings.Repeat("A", 47)+"-").Error
		}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			db := oauthRelayTestDB(t)
			user := oauthRelayFixture(t, db, 11, "stable-sub-A")
			token, err := GetOrCreateOAuthRelayToken(user.Id)
			if err != nil {
				t.Fatal(err)
			}
			if err := tc.mutate(db, token); err != nil {
				t.Fatal(err)
			}
			if found, err := GetOrCreateOAuthRelayToken(user.Id); found != nil || !errors.Is(err, ErrOAuthRelayCredentialUnavailable) {
				t.Fatal("revoked/corrupt credential was repaired or reissued")
			}
			var count int64
			if err := db.Unscoped().Model(&Token{}).Where("user_id = ?", user.Id).Count(&count).Error; err != nil || count != 1 {
				t.Fatal("a replacement credential was created")
			}
		})
	}
}

func TestOAuthRelayCredentialHiddenFromUserTokenManagement(t *testing.T) {
	db := oauthRelayTestDB(t)
	user := oauthRelayFixture(t, db, 11, "stable-sub-A")
	oauthRelayFixture(t, db, 12, "stable-sub-B")
	internal, err := GetOrCreateOAuthRelayToken(user.Id)
	if err != nil {
		t.Fatal(err)
	}
	normal1 := oauthRelayNormalToken(t, user.Id, "normal-one")
	normal2 := oauthRelayNormalToken(t, user.Id, "normal-two")
	other := oauthRelayNormalToken(t, 12, "other-user")
	listed, err := GetAllUserTokens(user.Id, 0, 100)
	if err != nil || len(listed) != 2 {
		t.Fatal("self token list included internal/other user's credentials")
	}
	if count, err := CountUserTokens(user.Id); err != nil || count != 2 {
		t.Fatal("self token count included internal credentials")
	}
	searched, count, err := SearchUserTokens(user.Id, "", "", 0, 100)
	if err != nil || count != 2 || len(searched) != 2 {
		t.Fatal("self token search included internal credentials")
	}
	searched, count, err = SearchUserTokens(user.Id, "", internal.Key, 0, 100)
	if err != nil || count != 0 || len(searched) != 0 {
		t.Fatal("exact key search exposed internal credentials")
	}
	if _, err := GetTokenByIds(internal.Id, user.Id); !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatal("self fetch/key/update guard accepted internal credential")
	}
	if err := DeleteTokenById(internal.Id, user.Id); !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatal("self delete accepted internal credential")
	}
	keys, err := GetTokenKeysByIds([]int{internal.Id, normal1.Id, other.Id}, user.Id)
	if err != nil || len(keys) != 1 || keys[0].Id != normal1.Id {
		t.Fatal("batch key export exposed internal/other user's credential")
	}
	removed, err := BatchDeleteTokens([]int{internal.Id, normal1.Id, other.Id}, user.Id)
	if err != nil || removed != 1 {
		t.Fatal("batch delete affected protected credentials")
	}
	for _, token := range []*Token{internal, normal2, other} {
		if _, err := GetTokenById(token.Id); err != nil {
			t.Fatal("protected/untargeted token was deleted")
		}
	}
	if byKey, err := GetTokenByKey(internal.Key, true); err != nil || byKey.Id != internal.Id {
		t.Fatal("ordinary internal billing lookup no longer finds its credential")
	}
}

func TestOAuthRelayRevokeIsPermanentAndDoesNotClaimMissingRows(t *testing.T) {
	db := oauthRelayTestDB(t)
	user := oauthRelayFixture(t, db, 11, "stable-sub-A")
	if err := RevokeOAuthRelayToken(user.Id); !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatal("revoking an absent credential claimed success")
	}
	internal, err := GetOrCreateOAuthRelayToken(user.Id)
	if err != nil {
		t.Fatal(err)
	}
	normal := oauthRelayNormalToken(t, user.Id, "normal-one")
	for i := 0; i < 2; i++ {
		if err := RevokeOAuthRelayToken(user.Id); err != nil {
			t.Fatal(err)
		}
	}
	if token, err := GetOrCreateOAuthRelayToken(user.Id); token != nil || !errors.Is(err, ErrOAuthRelayCredentialUnavailable) {
		t.Fatal("revoked credential was reissued")
	}
	var stored Token
	if err := db.Unscoped().First(&stored, internal.Id).Error; err != nil || stored.Status != common.TokenStatusDisabled {
		t.Fatal("internal credential was not disabled")
	}
	if found, err := GetTokenById(normal.Id); err != nil || found.Status != common.TokenStatusEnabled {
		t.Fatal("revocation changed a normal user token")
	}
	if current, err := GetUserById(user.Id, false); err != nil || current.Quota != user.Quota || current.Role != user.Role {
		t.Fatal("revocation modified user quota or role")
	}
}
