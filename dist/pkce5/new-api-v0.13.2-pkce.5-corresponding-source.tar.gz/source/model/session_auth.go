package model

import "gorm.io/gorm"

// CheckSessionUserExists rejects only a missing/soft-deleted account. It does
// not refresh role, status, username or group for existing cookie sessions.
// Using User preserves GORM's soft-delete scope; only the ID is selected.
func CheckSessionUserExists(id int) error {
	if id <= 0 {
		return gorm.ErrRecordNotFound
	}
	var user User
	return DB.Select("id").First(&user, id).Error
}
