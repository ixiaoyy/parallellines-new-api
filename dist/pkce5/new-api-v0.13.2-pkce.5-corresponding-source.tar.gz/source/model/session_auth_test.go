package model

import (
	"errors"
	"testing"

	"github.com/glebarez/sqlite"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

func TestSessionRevocationNarrowProjectionAndLegacyLookup(t *testing.T) {
	db, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	require.NoError(t, err)
	oldDB := DB
	DB = db
	t.Cleanup(func() { sqlDB, _ := db.DB(); _ = sqlDB.Close(); DB = oldDB })
	// No role/status/profile/credential columns exist: this must remain only an
	// account-existence query, preserving existing cookie claims for valid IDs.
	require.NoError(t, db.Exec("CREATE TABLE users (id integer PRIMARY KEY, deleted_at datetime)").Error)
	require.NoError(t, db.Exec("INSERT INTO users (id) VALUES (1)").Error)
	require.NoError(t, CheckSessionUserExists(1))
	require.NoError(t, db.Delete(&User{}, 1).Error)
	require.ErrorIs(t, CheckSessionUserExists(1), gorm.ErrRecordNotFound)
	legacy := &User{Id: 1}
	require.ErrorIs(t, legacy.FillUserById(), gorm.ErrRecordNotFound)
	require.NoError(t, db.Unscoped().Delete(&User{}, 1).Error)
	require.ErrorIs(t, CheckSessionUserExists(1), gorm.ErrRecordNotFound)
	require.ErrorIs(t, legacy.FillUserById(), gorm.ErrRecordNotFound)
	for _, id := range []int{0, -1} {
		require.ErrorIs(t, CheckSessionUserExists(id), gorm.ErrRecordNotFound)
	}
	require.NoError(t, db.Callback().Query().Before("gorm:query").Register("session_lookup_failure", func(tx *gorm.DB) { tx.AddError(errors.New("synthetic-private-driver-detail")) }))
	err = legacy.FillUserById()
	require.ErrorIs(t, err, ErrDatabase)
	require.NotContains(t, err.Error(), "synthetic-private-driver-detail")
}
