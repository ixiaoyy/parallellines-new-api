package oauth

import (
	"errors"
	"net/mail"
	"os"
	"strings"
	"unicode/utf8"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
)

const mainProfileIssuer = "https://pingxingxian.space/auth/oidc"
const mainProfileClient = "parallellines-newapi"

var ErrMainProfileConfig = errors.New("Main profile synchronization configuration is invalid")
var ErrMainProfileUnverified = errors.New("Main profile is incomplete or its email is not verified")

// An intended Main provider with changed identifiers must fail closed, not fall
// back to the generic provider's permissive registration path.
func (p *GenericOAuthProvider) MainProfileSyncRequired() bool {
	return os.Getenv("MAIN_OAUTH_PROFILE_SYNC_ENABLED") == "true" &&
		(p.config.Id == 1 || p.config.Slug == "pingxingxian" || p.config.ClientId == mainProfileClient)
}

func (p *GenericOAuthProvider) ValidateMainProfileConfiguration() error {
	c := p.config
	if c.Id != 1 || c.Slug != "pingxingxian" || c.ClientId != mainProfileClient || !c.Enabled ||
		c.UserIdField != "sub" || c.UsernameField != "preferred_username" ||
		c.DisplayNameField != "name" || c.EmailField != "email" ||
		c.UserInfoEndpoint != mainProfileIssuer+"/me" ||
		c.TokenEndpoint != mainProfileIssuer+"/token" ||
		c.AuthorizationEndpoint != mainProfileIssuer+"/auth" || c.AuthStyle != AuthStyleInHeader ||
		!CustomPKCEEnabled(c.Slug) {
		return ErrMainProfileConfig
	}
	return nil
}

// This parser is invoked only on the authenticated, exact Main UserInfo response.
// bool decoding deliberately rejects the strings "true" and "false".
func (p *GenericOAuthProvider) parseMainProfile(body []byte) (*OAuthUser, error) {
	if err := p.ValidateMainProfileConfiguration(); err != nil {
		return nil, err
	}
	var claims struct {
		Issuer        string `json:"iss"`
		Audience      string `json:"aud"`
		Subject       string `json:"sub"`
		Username      string `json:"preferred_username"`
		Name          string `json:"name"`
		Email         string `json:"email"`
		EmailVerified bool   `json:"email_verified"`
	}
	if common.Unmarshal(body, &claims) != nil || claims.Issuer != mainProfileIssuer ||
		claims.Audience != mainProfileClient || !claims.EmailVerified {
		return nil, ErrMainProfileUnverified
	}
	user := &OAuthUser{ProviderUserID: claims.Subject, Username: claims.Username,
		DisplayName: claims.Name, Email: strings.ToLower(claims.Email),
		Extra: map[string]any{"provider": p.config.Slug, "main_profile_verified": true}}
	if err := ValidateMainProfile(user); err != nil {
		return nil, err
	}
	return user, nil
}

func ValidateMainProfile(user *OAuthUser) error {
	if user == nil || user.Extra["main_profile_verified"] != true ||
		strings.TrimSpace(user.ProviderUserID) == "" || len(user.ProviderUserID) > 128 ||
		strings.TrimSpace(user.Username) == "" || utf8.RuneCountInString(user.Username) > model.UserNameMaxLength ||
		strings.TrimSpace(user.DisplayName) == "" || utf8.RuneCountInString(user.DisplayName) > 20 ||
		user.Email == "" || utf8.RuneCountInString(user.Email) > 50 || user.Email != strings.TrimSpace(user.Email) {
		return ErrMainProfileUnverified
	}
	address, err := mail.ParseAddress(user.Email)
	if err != nil || address.Address != user.Email {
		return ErrMainProfileUnverified
	}
	return nil
}
