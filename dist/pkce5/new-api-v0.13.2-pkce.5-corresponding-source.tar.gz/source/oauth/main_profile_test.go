package oauth

import (
	"context"
	"io"
	"net/http"
	"strings"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
)

func profileTestProvider(t *testing.T) *GenericOAuthProvider {
	t.Helper()
	t.Setenv("MAIN_OAUTH_PROFILE_SYNC_ENABLED", "true")
	t.Setenv("CUSTOM_OAUTH_PKCE_PROVIDERS", "pingxingxian")
	return NewGenericOAuthProvider(&model.CustomOAuthProvider{Id: 1, Slug: "pingxingxian", Enabled: true,
		ClientId: mainProfileClient, AuthStyle: AuthStyleInHeader, UserIdField: "sub", UsernameField: "preferred_username",
		DisplayNameField: "name", EmailField: "email", AuthorizationEndpoint: mainProfileIssuer + "/auth",
		TokenEndpoint: mainProfileIssuer + "/token", UserInfoEndpoint: mainProfileIssuer + "/me"})
}

func profileTestClaims() map[string]any {
	return map[string]any{"iss": mainProfileIssuer, "aud": mainProfileClient, "sub": "53",
		"preferred_username": "main-name", "name": "Main display", "email": "SYNTHETIC@example.invalid", "email_verified": true}
}

func TestMainProfileClaimsStrictAndPrivate(t *testing.T) {
	p := profileTestProvider(t)
	claims := profileTestClaims()
	body, _ := common.Marshal(claims)
	user, err := p.parseMainProfile(body)
	if err != nil || user.ProviderUserID != "53" || user.Email != "synthetic@example.invalid" {
		t.Fatal("valid profile rejected")
	}
	for _, mutation := range []struct {
		key   string
		value any
	}{
		{"email_verified", "true"}, {"email_verified", false}, {"email_verified", nil},
		{"iss", "https://other.invalid"}, {"aud", "parallellines-openwebui"}, {"aud", []string{mainProfileClient}},
		{"sub", 53}, {"sub", ""}, {"preferred_username", ""}, {"preferred_username", strings.Repeat("a", 21)},
		{"name", strings.Repeat("a", 21)}, {"email", "not-an-email"}, {"email", "Name <x@example.invalid>"},
		{"email", strings.Repeat("a", 51) + "@example.invalid"},
	} {
		claims := profileTestClaims()
		claims[mutation.key] = mutation.value
		body, _ := common.Marshal(claims)
		if _, err := p.parseMainProfile(body); err != ErrMainProfileUnverified {
			t.Fatalf("invalid %s was not safely rejected", mutation.key)
		}
	}
}

func TestMainProfileConfigurationCannotFallback(t *testing.T) {
	p := profileTestProvider(t)
	if !p.MainProfileSyncRequired() || p.ValidateMainProfileConfiguration() != nil {
		t.Fatal("valid config rejected")
	}
	for _, change := range []func(*model.CustomOAuthProvider){
		func(c *model.CustomOAuthProvider) { c.Id = 2 }, func(c *model.CustomOAuthProvider) { c.Slug = "other" },
		func(c *model.CustomOAuthProvider) { c.ClientId = "other" }, func(c *model.CustomOAuthProvider) { c.UserInfoEndpoint += "/" },
		func(c *model.CustomOAuthProvider) { c.UsernameField = "email" }, func(c *model.CustomOAuthProvider) { c.EmailField = "other" },
		func(c *model.CustomOAuthProvider) { c.AuthStyle = AuthStyleInParams }, func(c *model.CustomOAuthProvider) { c.Enabled = false },
	} {
		copyConfig := *p.config
		change(&copyConfig)
		other := NewGenericOAuthProvider(&copyConfig)
		if !other.MainProfileSyncRequired() || other.ValidateMainProfileConfiguration() != ErrMainProfileConfig {
			t.Fatal("mutated Main config fell back")
		}
	}
	other := NewGenericOAuthProvider(&model.CustomOAuthProvider{Id: 2, Slug: "other", ClientId: "other"})
	if other.MainProfileSyncRequired() {
		t.Fatal("unrelated provider altered")
	}
	t.Setenv("CUSTOM_OAUTH_PKCE_PROVIDERS", "")
	if p.ValidateMainProfileConfiguration() != ErrMainProfileConfig {
		t.Fatal("PKCE disabled was allowed")
	}
}

func TestMainProfileUsernameUnicodeCharacterLimit(t *testing.T) {
	p := profileTestProvider(t)
	for _, count := range []int{7, 20, 21} {
		claims := profileTestClaims()
		claims["preferred_username"] = strings.Repeat("名", count)
		body, err := common.Marshal(claims)
		if err != nil {
			t.Fatal(err)
		}
		user, err := p.parseMainProfile(body)
		if count <= model.UserNameMaxLength {
			if err != nil || user.Username != claims["preferred_username"] {
				t.Fatalf("valid %d-character Chinese username was rejected or altered", count)
			}
		} else if err != ErrMainProfileUnverified {
			t.Fatal("21-character Chinese username was not rejected")
		}
	}
}

type profileRoundTrip func(*http.Request) (*http.Response, error)

func (fn profileRoundTrip) RoundTrip(r *http.Request) (*http.Response, error) { return fn(r) }

func TestMainProfileUserInfoUsesExactEndpointRejectsRedirectAndOversize(t *testing.T) {
	p := profileTestProvider(t)
	original := http.DefaultTransport
	t.Cleanup(func() { http.DefaultTransport = original })
	for _, testCase := range []struct {
		status int
		body   string
		okay   bool
	}{
		{200, func() string { b, _ := common.Marshal(profileTestClaims()); return string(b) }(), true},
		{302, "", false}, {200, strings.Repeat("x", 16385), false},
	} {
		calls := 0
		http.DefaultTransport = profileRoundTrip(func(r *http.Request) (*http.Response, error) {
			calls++
			if r.URL.String() != mainProfileIssuer+"/me" || r.Header.Get("Authorization") != "Bearer synthetic" {
				t.Fatal("wrong protected endpoint")
			}
			return &http.Response{StatusCode: testCase.status, Body: io.NopCloser(strings.NewReader(testCase.body)), Header: http.Header{"Location": []string{"https://other.invalid"}}, Request: r}, nil
		})
		_, err := p.GetUserInfo(context.Background(), &OAuthToken{AccessToken: "synthetic"})
		if (err == nil) != testCase.okay || calls != 1 {
			t.Fatal("userinfo acceptance/redirect policy mismatch")
		}
	}
}
