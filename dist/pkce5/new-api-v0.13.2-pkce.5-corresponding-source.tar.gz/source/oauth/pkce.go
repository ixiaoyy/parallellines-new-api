package oauth

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"net/url"
	"os"
	"strings"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	"github.com/QuantumNous/new-api/setting/system_setting"
)

const PKCEVerifierContextKey = "custom_oauth_pkce_verifier"
const PKCERedirectContextKey = "custom_oauth_pkce_redirect"

// CustomPKCEEnabled is explicitly opt-in per custom provider slug. Legacy providers
// retain their upstream behavior; selected providers never fall back without PKCE.
func CustomPKCEEnabled(slug string) bool {
	for _, allowed := range strings.Split(os.Getenv("CUSTOM_OAUTH_PKCE_PROVIDERS"), ",") {
		if strings.TrimSpace(allowed) == slug && slug != "" {
			return true
		}
	}
	return false
}

func (p *GenericOAuthProvider) Snapshot() *GenericOAuthProvider {
	config := *p.config
	return NewGenericOAuthProvider(&config)
}

// PKCEConfiguration freezes the trusted redirect and all provider security settings.
// The client secret is excluded from the model's JSON, so include it explicitly in
// this internal hash. Neither the payload nor its digest is returned to browsers.
func (p *GenericOAuthProvider) PKCEConfiguration() (string, string, error) {
	base, err := url.Parse(system_setting.ServerAddress)
	if err != nil || base.Scheme != "https" || base.Host == "" || base.User != nil ||
		base.RawQuery != "" || base.Fragment != "" || (base.Path != "" && base.Path != "/") {
		return "", "", fmt.Errorf("PKCE requires an HTTPS ServerAddress origin")
	}
	for _, endpoint := range []string{p.config.AuthorizationEndpoint, p.config.TokenEndpoint, p.config.UserInfoEndpoint} {
		u, parseErr := url.Parse(endpoint)
		if parseErr != nil || u.Scheme != "https" || u.Host == "" || u.User != nil || u.Fragment != "" {
			return "", "", fmt.Errorf("PKCE requires HTTPS provider endpoints")
		}
	}
	redirect := strings.TrimRight(system_setting.ServerAddress, "/") + "/oauth/" + p.config.Slug
	payload, err := common.Marshal(struct {
		Provider model.CustomOAuthProvider
		Secret   string
		Redirect string
	}{*p.config, p.config.ClientSecret, redirect})
	if err != nil {
		return "", "", err
	}
	hash := sha256.Sum256(payload)
	return redirect, hex.EncodeToString(hash[:]), nil
}
