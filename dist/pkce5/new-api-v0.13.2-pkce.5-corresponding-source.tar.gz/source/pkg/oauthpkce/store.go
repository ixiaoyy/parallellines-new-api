// Package oauthpkce holds short-lived, single-use OAuth authorization transactions.
// It deliberately stores verifiers on the server, never in the signed session cookie.
package oauthpkce

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"sync"
	"time"
)

var (
	ErrInvalidState = errors.New("invalid or expired OAuth transaction")
	ErrCapacity     = errors.New("too many pending OAuth transactions")
)

type Binding struct {
	Session     string
	UserID      int
	ProviderID  int
	Fingerprint string
}

type transaction struct {
	binding  Binding
	verifier string
	expires  time.Time
}

type Store struct {
	mu       sync.Mutex
	pending  map[[32]byte]transaction
	ttl      time.Duration
	capacity int
	now      func() time.Time
}

func NewStore(ttl time.Duration, capacity int) *Store {
	return &Store{pending: make(map[[32]byte]transaction), ttl: ttl, capacity: capacity, now: time.Now}
}

func RandomValue() (string, error) {
	var b [32]byte
	if _, err := rand.Read(b[:]); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(b[:]), nil
}

func Challenge(verifier string) string {
	digest := sha256.Sum256([]byte(verifier))
	return base64.RawURLEncoding.EncodeToString(digest[:])
}

func (s *Store) prune(now time.Time) {
	for key, tx := range s.pending {
		if !now.Before(tx.expires) {
			delete(s.pending, key)
		}
	}
}

func (s *Store) Issue(binding Binding) (string, string, error) {
	if binding.Session == "" || binding.ProviderID <= 0 || binding.Fingerprint == "" {
		return "", "", ErrInvalidState
	}
	state, err := RandomValue()
	if err != nil {
		return "", "", err
	}
	verifier, err := RandomValue()
	if err != nil {
		return "", "", err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	now := s.now()
	s.prune(now)
	count := 0
	for _, tx := range s.pending {
		if tx.binding.Session == binding.Session {
			count++
		}
	}
	if len(s.pending) >= s.capacity || count >= 8 {
		return "", "", ErrCapacity
	}
	key := sha256.Sum256([]byte(state))
	if _, exists := s.pending[key]; exists {
		return "", "", ErrCapacity
	}
	s.pending[key] = transaction{binding: binding, verifier: verifier, expires: now.Add(s.ttl)}
	return state, Challenge(verifier), nil
}

// Consume rejects mismatched sessions without burning another browser's transaction.
// A matched transaction is removed atomically before any token exchange is attempted.
func (s *Store) Consume(state string, binding Binding) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.prune(s.now())
	key := sha256.Sum256([]byte(state))
	tx, ok := s.pending[key]
	if !ok || state == "" || tx.binding != binding {
		return "", ErrInvalidState
	}
	delete(s.pending, key)
	return tx.verifier, nil
}
