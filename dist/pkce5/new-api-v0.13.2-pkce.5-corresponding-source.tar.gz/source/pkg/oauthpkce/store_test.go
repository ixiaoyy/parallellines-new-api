package oauthpkce

import (
	"encoding/base64"
	"errors"
	"strconv"
	"sync"
	"testing"
	"time"
)

func testBinding() Binding {
	return Binding{
		Session:     "test-browser-binding",
		UserID:      17,
		ProviderID:  3,
		Fingerprint: "test-config-fingerprint",
	}
}

func requireRandomValue(t *testing.T, label, value string) {
	t.Helper()
	if len(value) != 43 {
		t.Fatalf("%s length = %d, want 43", label, len(value))
	}
	decoded, err := base64.RawURLEncoding.DecodeString(value)
	if err != nil {
		t.Fatalf("%s is not unpadded base64url: %v", label, err)
	}
	if len(decoded) != 32 {
		t.Fatalf("%s decodes to %d bytes, want 32", label, len(decoded))
	}
}

func requireIssue(t *testing.T, store *Store, binding Binding) (string, string) {
	t.Helper()
	state, challenge, err := store.Issue(binding)
	if err != nil {
		t.Fatalf("Issue() error: %v", err)
	}
	requireRandomValue(t, "state", state)
	requireRandomValue(t, "challenge", challenge)
	return state, challenge
}

func requireConsume(t *testing.T, store *Store, state string, binding Binding, challenge string) {
	t.Helper()
	verifier, err := store.Consume(state, binding)
	if err != nil {
		t.Fatalf("Consume() error: %v", err)
	}
	requireRandomValue(t, "verifier", verifier)
	if verifier == state {
		t.Fatal("state and verifier must be generated independently")
	}
	if Challenge(verifier) != challenge {
		t.Fatal("consumed verifier does not match the issued S256 challenge")
	}
}

func requireInvalidState(t *testing.T, store *Store, state string, binding Binding) {
	t.Helper()
	verifier, err := store.Consume(state, binding)
	if !errors.Is(err, ErrInvalidState) {
		t.Fatalf("Consume() error = %v, want ErrInvalidState", err)
	}
	if verifier != "" {
		t.Fatal("rejected Consume() returned a verifier")
	}
}

func requireCapacity(t *testing.T, store *Store, binding Binding) {
	t.Helper()
	state, challenge, err := store.Issue(binding)
	if !errors.Is(err, ErrCapacity) {
		t.Fatalf("Issue() error = %v, want ErrCapacity", err)
	}
	if state != "" || challenge != "" {
		t.Fatal("rejected Issue() returned transaction material")
	}
}

func TestChallengeRFC7636(t *testing.T) {
	// RFC 7636, Appendix B: public S256 example, not a real credential.
	const verifier = "dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk"
	const expected = "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM"
	if got := Challenge(verifier); got != expected {
		t.Fatalf("Challenge(RFC example) = %q, want %q", got, expected)
	}
}

func TestRandomValueFormatAndUniqueness(t *testing.T) {
	seen := make(map[string]bool)
	for i := 0; i < 64; i++ {
		value, err := RandomValue()
		if err != nil {
			t.Fatalf("RandomValue() error: %v", err)
		}
		requireRandomValue(t, "random value", value)
		if seen[value] {
			t.Fatal("RandomValue() repeated a value")
		}
		seen[value] = true
	}
}

func TestStoreBindingMismatchDoesNotConsume(t *testing.T) {
	tests := []struct {
		name   string
		change func(*Binding)
	}{
		{"other session", func(b *Binding) { b.Session = "other-browser" }},
		{"missing session", func(b *Binding) { b.Session = "" }},
		{"other user", func(b *Binding) { b.UserID++ }},
		{"logged out", func(b *Binding) { b.UserID = 0 }},
		{"other provider", func(b *Binding) { b.ProviderID++ }},
		{"missing provider", func(b *Binding) { b.ProviderID = 0 }},
		{"changed config", func(b *Binding) { b.Fingerprint = "changed-config" }},
		{"missing config", func(b *Binding) { b.Fingerprint = "" }},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			store := NewStore(5*time.Minute, 16)
			binding := testBinding()
			state, challenge := requireIssue(t, store, binding)
			wrong := binding
			tt.change(&wrong)
			requireInvalidState(t, store, state, wrong)
			requireConsume(t, store, state, binding, challenge)
		})
	}
	t.Run("anonymous initiation then login", func(t *testing.T) {
		store := NewStore(5*time.Minute, 16)
		anonymous := testBinding()
		anonymous.UserID = 0
		state, challenge := requireIssue(t, store, anonymous)
		requireInvalidState(t, store, state, testBinding())
		requireConsume(t, store, state, anonymous, challenge)
	})
}

func TestStoreMissingUnknownAndReplayedState(t *testing.T) {
	store := NewStore(5*time.Minute, 16)
	binding := testBinding()
	state, challenge := requireIssue(t, store, binding)
	requireInvalidState(t, store, "", binding)
	requireInvalidState(t, store, "unknown-state", binding)
	requireConsume(t, store, state, binding, challenge)
	requireInvalidState(t, store, state, binding)
}

func TestStoreExpiryBoundary(t *testing.T) {
	const ttl = 5 * time.Minute
	base := time.Date(2026, time.January, 1, 0, 0, 0, 0, time.UTC)
	for _, tt := range []struct {
		name    string
		elapsed time.Duration
		expired bool
	}{
		{"just before expiry", ttl - time.Nanosecond, false},
		{"exactly at expiry", ttl, true},
		{"after expiry", ttl + time.Nanosecond, true},
	} {
		t.Run(tt.name, func(t *testing.T) {
			now := base
			store := NewStore(ttl, 16)
			store.now = func() time.Time { return now }
			binding := testBinding()
			state, challenge := requireIssue(t, store, binding)
			now = base.Add(tt.elapsed)
			if tt.expired {
				requireInvalidState(t, store, state, binding)
			} else {
				requireConsume(t, store, state, binding, challenge)
			}
		})
	}
}

func TestStoreMultipleTabsAreIndependent(t *testing.T) {
	store := NewStore(5*time.Minute, 16)
	binding := testBinding()
	var states, challenges []string
	seen := make(map[string]bool)
	for i := 0; i < 5; i++ {
		state, challenge := requireIssue(t, store, binding)
		if seen[state] {
			t.Fatal("Issue() repeated a pending state")
		}
		seen[state] = true
		states = append(states, state)
		challenges = append(challenges, challenge)
	}
	// Tabs may complete in a different order from their initiation.
	for i := len(states) - 1; i >= 0; i-- {
		requireConsume(t, store, states[i], binding, challenges[i])
		requireInvalidState(t, store, states[i], binding)
	}
}

func TestStoreConcurrentConsumeHasExactlyOneWinner(t *testing.T) {
	store := NewStore(5*time.Minute, 16)
	binding := testBinding()
	state, challenge := requireIssue(t, store, binding)
	const attempts = 64
	type result struct {
		verifier string
		err      error
	}
	start := make(chan struct{})
	results := make(chan result, attempts)
	var wg sync.WaitGroup
	for i := 0; i < attempts; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			<-start
			verifier, err := store.Consume(state, binding)
			results <- result{verifier, err}
		}()
	}
	close(start)
	wg.Wait()
	close(results)
	winners := 0
	for result := range results {
		if result.err == nil {
			winners++
			requireRandomValue(t, "winning verifier", result.verifier)
			if Challenge(result.verifier) != challenge {
				t.Fatal("winning verifier does not match challenge")
			}
		} else if !errors.Is(result.err, ErrInvalidState) || result.verifier != "" {
			t.Fatalf("losing Consume() returned unexpected result: error=%v, verifier present=%t", result.err, result.verifier != "")
		}
	}
	if winners != 1 {
		t.Fatalf("successful concurrent consumes = %d, want 1", winners)
	}
}

func TestStoreGlobalCapacityDoesNotEvictPendingTransactions(t *testing.T) {
	store := NewStore(5*time.Minute, 2)
	a, b, c := testBinding(), testBinding(), testBinding()
	b.Session = "browser-b"
	c.Session = "browser-c"
	stateA, challengeA := requireIssue(t, store, a)
	stateB, challengeB := requireIssue(t, store, b)
	requireCapacity(t, store, c)
	requireConsume(t, store, stateA, a, challengeA)
	stateC, challengeC := requireIssue(t, store, c)
	requireConsume(t, store, stateB, b, challengeB)
	requireConsume(t, store, stateC, c, challengeC)
}

func TestStorePerBindingCapacityDoesNotEvictPendingTransactions(t *testing.T) {
	store := NewStore(5*time.Minute, 32)
	binding := testBinding()
	var states, challenges []string
	for i := 0; i < 8; i++ {
		state, challenge := requireIssue(t, store, binding)
		states = append(states, state)
		challenges = append(challenges, challenge)
	}
	requireCapacity(t, store, binding)
	other := binding
	other.Session = "other-browser"
	otherState, otherChallenge := requireIssue(t, store, other)
	requireConsume(t, store, states[0], binding, challenges[0])
	replacement, replacementChallenge := requireIssue(t, store, binding)
	for i := 1; i < len(states); i++ {
		requireConsume(t, store, states[i], binding, challenges[i])
	}
	requireConsume(t, store, replacement, binding, replacementChallenge)
	requireConsume(t, store, otherState, other, otherChallenge)
}

func TestStoreExpiryReleasesCapacity(t *testing.T) {
	const ttl = 5 * time.Minute
	for _, tt := range []struct {
		name     string
		capacity int
		count    int
	}{
		{"global capacity", 2, 2},
		{"per binding capacity", 32, 8},
	} {
		t.Run(tt.name, func(t *testing.T) {
			now := time.Date(2026, time.January, 1, 0, 0, 0, 0, time.UTC)
			store := NewStore(ttl, tt.capacity)
			store.now = func() time.Time { return now }
			binding := testBinding()
			var oldStates []string
			for i := 0; i < tt.count; i++ {
				state, _ := requireIssue(t, store, binding)
				oldStates = append(oldStates, state)
			}
			requireCapacity(t, store, binding)
			now = now.Add(ttl)
			// Issue must recover expired capacity without a prior Consume call.
			state, challenge := requireIssue(t, store, binding)
			for _, oldState := range oldStates {
				requireInvalidState(t, store, oldState, binding)
			}
			requireConsume(t, store, state, binding, challenge)
		})
	}
}

func TestStoreConcurrentIssueHonorsCapacity(t *testing.T) {
	for _, tt := range []struct {
		name        string
		capacity    int
		wantIssued  int
		sameBinding bool
	}{
		{"global capacity", 16, 16, false},
		{"per binding capacity", 64, 8, true},
	} {
		t.Run(tt.name, func(t *testing.T) {
			store := NewStore(5*time.Minute, tt.capacity)
			const attempts = 64
			type result struct {
				state     string
				challenge string
				binding   Binding
				err       error
			}
			start := make(chan struct{})
			results := make(chan result, attempts)
			var wg sync.WaitGroup
			for i := 0; i < attempts; i++ {
				binding := testBinding()
				if !tt.sameBinding {
					binding.Session = "test-browser-" + strconv.Itoa(i)
				}
				wg.Add(1)
				go func(binding Binding) {
					defer wg.Done()
					<-start
					state, challenge, err := store.Issue(binding)
					results <- result{state, challenge, binding, err}
				}(binding)
			}
			close(start)
			wg.Wait()
			close(results)
			seen := make(map[string]bool)
			for result := range results {
				if result.err != nil {
					if !errors.Is(result.err, ErrCapacity) || result.state != "" || result.challenge != "" {
						t.Fatalf("rejected Issue() returned unexpected result: %v", result.err)
					}
					continue
				}
				if seen[result.state] {
					t.Fatal("concurrent Issue() repeated a pending state")
				}
				seen[result.state] = true
				requireConsume(t, store, result.state, result.binding, result.challenge)
			}
			if len(seen) != tt.wantIssued {
				t.Fatalf("successful concurrent issues = %d, want %d", len(seen), tt.wantIssued)
			}
		})
	}
}
