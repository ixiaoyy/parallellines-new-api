package openai

import (
	"encoding/json"
	"errors"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/dto"
	"github.com/QuantumNous/new-api/service"
	"github.com/gin-gonic/gin"
)

func standardUsageFromEnvelope(raw []byte, responses bool) (*dto.OpenAIStandardUsage, error) {
	var envelope map[string]json.RawMessage
	if common.Unmarshal(raw, &envelope) != nil || envelope == nil {
		return nil, errors.New("invalid_response_envelope")
	}
	return service.ParseOpenAIStandardUsage(envelope["usage"], responses)
}

func standardUsageFromResponsesEvent(raw []byte) (*dto.OpenAIStandardUsage, error) {
	var envelope map[string]json.RawMessage
	if common.Unmarshal(raw, &envelope) != nil || envelope == nil {
		return nil, errors.New("invalid_response_event")
	}
	return standardUsageFromEnvelope(envelope["response"], true)
}

func applyStandardUsage(usage *dto.Usage, verified *dto.OpenAIStandardUsage) {
	usage.StandardOpenAIUsage = verified
	usage.PromptTokens = verified.InputTokensTotal
	usage.InputTokens = verified.InputTokensTotal
	usage.CompletionTokens = verified.OutputTokens
	usage.OutputTokens = verified.OutputTokens
	usage.TotalTokens = verified.InputTokensTotal + verified.OutputTokens
	usage.PromptTokensDetails.CachedTokens = verified.CacheReadTokens
	write := verified.CacheWrite30mTokens + verified.CacheWrite12hTokens
	usage.PromptTokensDetails.CacheWriteTokens = &write
	usage.PromptTokensDetails.CacheWriteTokensDetails = &dto.OpenAICacheWriteTokenDetails{
		TTL30mTokens: &verified.CacheWrite30mTokens, TTL12hTokens: &verified.CacheWrite12hTokens,
	}
	usage.UsageSource = "openai_standard_verified"
}

func standardChatHasOutput(raw []byte) bool {
	type outputContent struct {
		Content          json.RawMessage   `json:"content"`
		ReasoningContent string            `json:"reasoning_content"`
		Reasoning        string            `json:"reasoning"`
		Refusal          *string           `json:"refusal"`
		ToolCalls        []json.RawMessage `json:"tool_calls"`
	}
	var response struct {
		Choices []struct {
			Message *outputContent `json:"message"`
			Delta   *outputContent `json:"delta"`
		} `json:"choices"`
	}
	if common.Unmarshal(raw, &response) != nil {
		return true
	}
	for _, choice := range response.Choices {
		for _, m := range []*outputContent{choice.Message, choice.Delta} {
			if m == nil {
				continue
			}
			if m.ReasoningContent != "" || m.Reasoning != "" || (m.Refusal != nil && *m.Refusal != "") || len(m.ToolCalls) != 0 {
				return true
			}
			if common.GetJsonType(m.Content) == "string" {
				var text string
				if common.Unmarshal(m.Content, &text) != nil || text != "" {
					return true
				}
			} else if len(m.Content) > 0 && common.GetJsonType(m.Content) != "null" {
				return true
			}
		}
	}
	return false
}

func captureStandardResponsesSequence(c *gin.Context, raw []byte) {
	var envelope struct {
		Sequence *int `json:"sequence_number"`
	}
	if common.Unmarshal(raw, &envelope) != nil || envelope.Sequence == nil || *envelope.Sequence < 0 || *envelope.Sequence == int(^uint(0)>>1) {
		return
	}
	if _, present := c.Get("openai_standard_last_sequence"); !present || *envelope.Sequence > c.GetInt("openai_standard_last_sequence") {
		c.Set("openai_standard_last_sequence", *envelope.Sequence)
	}
}

// Strip only the outgoing copy. The original frame remains available for
// strict usage validation and billing, including duplicate-frame checks.
func standardChatOutputWithoutUsage(data string) (string, error) {
	var envelope map[string]json.RawMessage
	if common.UnmarshalJsonStr(data, &envelope) != nil || envelope == nil {
		return "", errors.New("invalid_stream_output_envelope")
	}
	if _, exists := envelope["usage"]; !exists {
		return data, nil
	}
	delete(envelope, "usage")
	encoded, err := common.Marshal(envelope)
	if err != nil {
		return "", errors.New("invalid_stream_output_envelope")
	}
	return string(encoded), nil
}
