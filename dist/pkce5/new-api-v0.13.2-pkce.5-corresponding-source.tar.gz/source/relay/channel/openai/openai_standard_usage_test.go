package openai

import (
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/dto"
	relaycommon "github.com/QuantumNous/new-api/relay/common"
	relayconstant "github.com/QuantumNous/new-api/relay/constant"
	"github.com/QuantumNous/new-api/service"
	"github.com/QuantumNous/new-api/types"
	"github.com/gin-gonic/gin"
)

const chatVerifiedUsage = `{"prompt_tokens":2000,"completion_tokens":1000,"total_tokens":3000,"prompt_tokens_details":{"cached_tokens":500,"cache_write_tokens":1000}}`
const responsesVerifiedUsage = `{"input_tokens":4000,"output_tokens":1000,"total_tokens":5000,"input_tokens_details":{"cached_tokens":500,"cache_write_tokens":2000,"cache_write_tokens_details":{"ttl_30m_tokens":1000,"ttl_12h_tokens":1000}}}`

func standardAdapterFixture(t *testing.T, responses, stream bool) (*gin.Context, *httptest.ResponseRecorder, *relaycommon.RelayInfo) {
	t.Helper()
	t.Setenv("OPENAI_STANDARD_BILLING_ENABLED", "true")
	gin.SetMode(gin.TestMode)
	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	c.Request = httptest.NewRequest(http.MethodPost, "/v1/chat/completions", nil)
	info := &relaycommon.RelayInfo{OriginModelName: "gpt-6-luna", RelayFormat: types.RelayFormatOpenAI, RelayMode: relayconstant.RelayModeChatCompletions, StartTime: time.Now(), ShouldIncludeUsage: true, IsStream: stream, DisablePing: true, ChannelMeta: &relaycommon.ChannelMeta{ChannelType: constant.ChannelTypeOpenAI, ChannelBaseUrl: "https://api.openai.com", UpstreamModelName: "gpt-6-luna"}}
	info.SetEstimatePromptTokens(99999)
	if responses {
		info.RelayFormat = types.RelayFormatOpenAIResponses
		info.RelayMode = relayconstant.RelayModeResponses
	}
	oldTimeout := constant.StreamingTimeout
	constant.StreamingTimeout = 5
	t.Cleanup(func() { constant.StreamingTimeout = oldTimeout })
	return c, w, info
}

func syntheticResponse(body string, stream bool) *http.Response {
	typeName := "application/json"
	if stream {
		typeName = "text/event-stream"
	}
	return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": []string{typeName}}, Body: io.NopCloser(strings.NewReader(body))}
}

func requireUnsettled(t *testing.T, usage *dto.Usage, err *types.NewAPIError) {
	t.Helper()
	if usage != nil || err == nil || err.StatusCode != 502 || err.GetErrorCode() != service.OpenAIStandardUsageErrorCode || !types.IsSkipRetryError(err) {
		t.Fatalf("expected explicit nonretryable usage failure; usage=%+v error=%v", usage, err)
	}
}

func TestStandardOpenAINonstreamUsage(t *testing.T) {
	t.Run("chat", func(t *testing.T) {
		c, w, info := standardAdapterFixture(t, false, false)
		u, e := OpenaiHandler(c, info, syntheticResponse(`{"id":"chat-test","choices":[{"message":{"content":"hello"},"finish_reason":"length"}],"usage":`+chatVerifiedUsage+`}`, false))
		if e != nil || u.StandardOpenAIUsage == nil || u.StandardOpenAIUsage.CacheWrite30mTokens != 1000 || u.PromptTokens != 2000 || w.Body.Len() == 0 {
			t.Fatalf("usage=%+v err=%v", u, e)
		}
	})
	t.Run("responses", func(t *testing.T) {
		c, w, info := standardAdapterFixture(t, true, false)
		u, e := OaiResponsesHandler(c, info, syntheticResponse(`{"id":"response-test","status":"completed","output":[],"usage":`+responsesVerifiedUsage+`}`, false))
		if e != nil || u.StandardOpenAIUsage == nil || u.StandardOpenAIUsage.CacheWrite12hTokens != 1000 || u.PromptTokens != 4000 || w.Body.Len() == 0 {
			t.Fatalf("usage=%+v err=%v", u, e)
		}
	})
	for _, responses := range []bool{false, true} {
		t.Run(map[bool]string{false: "chat_missing", true: "responses_missing"}[responses], func(t *testing.T) {
			c, w, info := standardAdapterFixture(t, responses, false)
			var u *dto.Usage
			var e *types.NewAPIError
			if responses {
				u, e = OaiResponsesHandler(c, info, syntheticResponse(`{"output":[]}`, false))
			} else {
				u, e = OpenaiHandler(c, info, syntheticResponse(`{"choices":[{"message":{"content":"sensitive-output"}}]}`, false))
			}
			requireUnsettled(t, u, e)
			if w.Body.Len() != 0 {
				t.Fatal("success body was sent before invalid usage rejected")
			}
		})
	}
	t.Run("other_model_unchanged", func(t *testing.T) {
		c, _, info := standardAdapterFixture(t, false, false)
		info.OriginModelName = "gpt-4o"
		info.UpstreamModelName = "gpt-4o"
		u, e := OpenaiHandler(c, info, syntheticResponse(`{"choices":[],"usage":{"prompt_tokens":3,"completion_tokens":1,"total_tokens":4,"prompt_tokens_details":{"cached_tokens":99}}}`, false))
		if e != nil || u.StandardOpenAIUsage != nil {
			t.Fatalf("unrelated model changed: usage=%+v err=%v", u, e)
		}
	})
}

func TestStandardOpenAIChatStreamUsage(t *testing.T) {
	start := `data: {"id":"chat-test","model":"gpt-6-luna","choices":[{"delta":{"content":"hello"},"finish_reason":null}],"usage":null}` + "\n\n"
	usageFrame := func(raw string) string {
		return `data: {"id":"chat-test","model":"gpt-6-luna","choices":[],"usage":` + raw + `}` + "\n\n"
	}
	for _, tt := range []struct {
		name, tail string
		fail       bool
	}{
		{"actual_final_usage", usageFrame(chatVerifiedUsage), false},
		{"identical_duplicate", usageFrame(chatVerifiedUsage) + usageFrame(chatVerifiedUsage), false},
		{"missing_final", "", true},
		{"partial_final", usageFrame(`{"prompt_tokens":2000}`), true},
		{"invalid_terminal_shape", `data: {"choices":"invalid","usage":` + chatVerifiedUsage + "}\n\n", true},
		{"conflicting_final", usageFrame(chatVerifiedUsage) + usageFrame(`{"prompt_tokens":2,"completion_tokens":1,"total_tokens":3}`), true},
		{"zero_with_output", usageFrame(`{"prompt_tokens":0,"completion_tokens":0,"total_tokens":0}`), true},
	} {
		t.Run(tt.name, func(t *testing.T) {
			c, w, info := standardAdapterFixture(t, false, true)
			u, e := OaiStreamHandler(c, info, syntheticResponse(start+tt.tail+"data: [DONE]\n\n", true))
			if tt.fail {
				requireUnsettled(t, u, e)
				if strings.Contains(w.Body.String(), "[DONE]") {
					t.Fatal("invalid usage stream ended as success")
				}
				return
			}
			if e != nil || u.StandardOpenAIUsage == nil || u.StandardOpenAIUsage.CacheWrite30mTokens != 1000 || u.PromptTokens != 2000 {
				t.Fatalf("usage=%+v err=%v", u, e)
			}
		})
	}
}

func TestStandardOpenAIResponsesStreamUsage(t *testing.T) {
	delta := `data: {"type":"response.output_text.delta","sequence_number":3,"delta":"hello"}` + "\n\n"
	terminal := func(kind, raw string) string {
		return `data: {"type":"` + kind + `","sequence_number":7,"response":{"id":"response-test","output":[],"usage":` + raw + `}}` + "\n\n"
	}
	for _, tt := range []struct {
		name, tail string
		fail       bool
	}{
		{"completed", terminal("response.completed", responsesVerifiedUsage), false},
		{"incomplete", terminal("response.incomplete", responsesVerifiedUsage), false},
		{"same_terminal_twice", terminal("response.completed", responsesVerifiedUsage) + terminal("response.completed", responsesVerifiedUsage), false},
		{"missing_terminal", "", true},
		{"missing_usage", terminal("response.completed", "null"), true},
		{"zero_with_output", terminal("response.completed", `{"input_tokens":0,"output_tokens":0,"total_tokens":0}`), true},
		{"conflicting_terminal", terminal("response.completed", responsesVerifiedUsage) + terminal("response.completed", `{"input_tokens":2,"output_tokens":1,"total_tokens":3}`), true},
	} {
		t.Run(tt.name, func(t *testing.T) {
			c, w, info := standardAdapterFixture(t, true, true)
			u, e := OaiResponsesStreamHandler(c, info, syntheticResponse(delta+tt.tail, true))
			wantSeq := 7
			if tt.tail == "" {
				wantSeq = 3
			}
			if c.GetInt("openai_standard_last_sequence") != wantSeq {
				t.Fatal("last upstream sequence was not retained for error event")
			}
			if tt.fail {
				requireUnsettled(t, u, e)
				if strings.Contains(w.Body.String(), "event: response.completed") || strings.Contains(w.Body.String(), "event: response.incomplete") {
					t.Fatal("invalid usage stream emitted a successful terminal event")
				}
				return
			}
			if e != nil || u.StandardOpenAIUsage == nil || u.StandardOpenAIUsage.CacheWrite12hTokens != 1000 || u.PromptTokens != 4000 {
				t.Fatalf("usage=%+v err=%v", u, e)
			}
			if strings.Count(w.Body.String(), "event: response.completed")+strings.Count(w.Body.String(), "event: response.incomplete") != 1 {
				t.Fatal("successful terminal event was duplicated or missing")
			}
		})
	}
}

func TestStandardChatRefusalCannotBeZeroUsage(t *testing.T) {
	for _, stream := range []bool{false, true} {
		t.Run(map[bool]string{false: "nonstream", true: "stream"}[stream], func(t *testing.T) {
			c, _, info := standardAdapterFixture(t, false, stream)
			var u *dto.Usage
			var err *types.NewAPIError
			if stream {
				body := `data: {"choices":[{"delta":{"refusal":"Cannot comply"}}]}` + "\n\n" + `data: {"choices":[],"usage":{"prompt_tokens":0,"completion_tokens":0,"total_tokens":0}}` + "\n\ndata: [DONE]\n\n"
				u, err = OaiStreamHandler(c, info, syntheticResponse(body, true))
			} else {
				u, err = OpenaiHandler(c, info, syntheticResponse(`{"choices":[{"message":{"refusal":"Cannot comply"}}],"usage":{"prompt_tokens":0,"completion_tokens":0,"total_tokens":0}}`, false))
			}
			requireUnsettled(t, u, err)
		})
	}
}

func TestStandardChatHiddenUsageStillSettlesActualCounters(t *testing.T) {
	start := `data: {"id":"chat-hidden-usage","model":"gpt-6-luna","choices":[{"delta":{"content":"hello"},"finish_reason":null}],"usage":null}` + "\n\n"
	final := `data: {"id":"chat-hidden-usage","model":"gpt-6-luna","choices":[],"usage":` + chatVerifiedUsage + "}\n\n"
	mixed := `data: {"id":"chat-hidden-usage","model":"gpt-6-luna","choices":[{"delta":{"content":"tail"}}],"usage":` + chatVerifiedUsage + "}\n\n"
	for _, tt := range []struct {
		name, tail string
		force      bool
	}{
		{"single", final, false},
		{"duplicate", final + final, false},
		{"usage_with_content_then_final", mixed + final, false},
		{"usage_with_final_content", mixed, false},
		{"duplicate_force_format", final + final, true},
	} {
		t.Run(tt.name, func(t *testing.T) {
			c, w, info := standardAdapterFixture(t, false, true)
			info.ShouldIncludeUsage = false
			info.ChannelSetting.ForceFormat = tt.force
			usage, err := OaiStreamHandler(c, info, syntheticResponse(start+tt.tail+"data: [DONE]\n\n", true))
			if err != nil || usage == nil || usage.StandardOpenAIUsage == nil || usage.PromptTokens != 2000 || usage.CompletionTokens != 1000 || usage.StandardOpenAIUsage.CacheWrite30mTokens != 1000 {
				t.Fatalf("real upstream counters were not retained for billing: usage=%+v err=%v", usage, err)
			}
			if !strings.Contains(w.Body.String(), "hello") || !strings.Contains(w.Body.String(), "[DONE]") || (strings.Contains(tt.tail, `"content":"tail"`) && !strings.Contains(w.Body.String(), "tail")) {
				t.Fatal("normal streamed output was not preserved")
			}
			for _, line := range strings.Split(w.Body.String(), "\n") {
				if !strings.HasPrefix(line, "data: ") {
					continue
				}
				data := strings.TrimSpace(strings.TrimPrefix(line, "data: "))
				if data == "[DONE]" {
					continue
				}
				var chunk map[string]json.RawMessage
				if err := common.UnmarshalJsonStr(data, &chunk); err != nil {
					t.Fatal(err)
				}
				if common.GetJsonType(chunk["usage"]) == "object" {
					t.Fatal("downstream received a usage object despite ShouldIncludeUsage=false")
				}
			}
		})
	}
}
