package helper

import (
	"net/http/httptest"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	relaycommon "github.com/QuantumNous/new-api/relay/common"
	relayconstant "github.com/QuantumNous/new-api/relay/constant"
	"github.com/QuantumNous/new-api/service"
	"github.com/QuantumNous/new-api/setting/ratio_setting"
	"github.com/QuantumNous/new-api/types"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/require"
)

func TestOpenAIStandardPriceScopeAndFailClosed(t *testing.T) {
	gin.SetMode(gin.TestMode)
	oldPrices := ratio_setting.ModelPrice2JSONString()
	t.Cleanup(func() { require.NoError(t, ratio_setting.UpdateModelPriceByJSONString(oldPrices)) })
	// A configured legacy price must not bypass the policy-off or endpoint guard.
	require.NoError(t, ratio_setting.UpdateModelPriceByJSONString(`{"gpt-6-luna":1,"unrelated-model":2}`))
	for _, tt := range []struct {
		name, model, base, flag string
		channel, mode           int
		wantPolicy, wantError   bool
	}{
		{"chat", "gpt-6-luna", "https://api.openai.com", "true", constant.ChannelTypeOpenAI, relayconstant.RelayModeChatCompletions, true, false},
		{"responses", "gpt-6-luna", "https://api.openai.com/v1", "true", constant.ChannelTypeOpenAI, relayconstant.RelayModeResponses, true, false},
		{"disabled", "gpt-6-luna", "https://api.openai.com", "false", constant.ChannelTypeOpenAI, relayconstant.RelayModeChatCompletions, false, true},
		{"compact", "gpt-6-luna", "https://api.openai.com", "true", constant.ChannelTypeOpenAI, relayconstant.RelayModeResponsesCompact, false, true},
		{"third-party", "gpt-6-luna", "https://example.invalid", "false", constant.ChannelTypeOpenAI, relayconstant.RelayModeChatCompletions, false, false},
		{"azure", "gpt-6-luna", "https://api.openai.com", "false", constant.ChannelTypeAzure, relayconstant.RelayModeChatCompletions, false, false},
		{"other-model", "unrelated-model", "https://api.openai.com", "false", constant.ChannelTypeOpenAI, relayconstant.RelayModeChatCompletions, false, false},
	} {
		t.Run(tt.name, func(t *testing.T) {
			t.Setenv("OPENAI_STANDARD_BILLING_ENABLED", tt.flag)
			c, _ := gin.CreateTestContext(httptest.NewRecorder())
			c.Request = httptest.NewRequest("POST", "/v1/chat/completions", nil)
			common.SetContextKey(c, constant.ContextKeyChannelType, tt.channel)
			common.SetContextKey(c, constant.ContextKeyChannelId, 1)
			common.SetContextKey(c, constant.ContextKeyChannelBaseUrl, tt.base)
			common.SetContextKey(c, constant.ContextKeyOriginalModel, tt.model)
			info := &relaycommon.RelayInfo{OriginModelName: tt.model, RelayMode: tt.mode, UserGroup: "default", UsingGroup: "default"}
			data, err := ModelPriceHelper(c, info, 10, &types.TokenCountMeta{MaxTokens: 5})
			require.Nil(t, info.ChannelMeta, "pricing must not trigger first-request channel reselection")
			if tt.wantError {
				require.Error(t, err)
				require.Empty(t, info.OpenAIStandardPolicy)
				return
			}
			require.NoError(t, err)
			if tt.wantPolicy {
				require.Equal(t, service.OpenAIStandardPolicyVersion, info.OpenAIStandardPolicy)
				require.False(t, data.UsePrice)
			} else {
				require.Empty(t, info.OpenAIStandardPolicy)
				require.True(t, data.UsePrice)
			}
		})
	}
}
