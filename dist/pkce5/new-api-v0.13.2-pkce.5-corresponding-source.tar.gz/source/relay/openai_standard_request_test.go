package relay

import (
	"fmt"
	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/dto"
	relaycommon "github.com/QuantumNous/new-api/relay/common"
	relayconstant "github.com/QuantumNous/new-api/relay/constant"
	"github.com/QuantumNous/new-api/service"
	"github.com/QuantumNous/new-api/types"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/require"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

type standardCaptureTransport func(*http.Request) (*http.Response, error)

func (f standardCaptureTransport) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

func TestOpenAIStandardRequestForcesUpstreamUsageWithoutNetwork(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("OPENAI_STANDARD_BILLING_ENABLED", "true")
	oldTimeout := constant.StreamingTimeout
	constant.StreamingTimeout = 5
	t.Cleanup(func() { constant.StreamingTimeout = oldTimeout })
	service.InitHttpClient()
	client := service.GetHttpClient()
	oldTransport := client.Transport
	t.Cleanup(func() { client.Transport = oldTransport })
	oldForce := constant.ForceStreamOption
	constant.ForceStreamOption = false
	t.Cleanup(func() { constant.ForceStreamOption = oldForce })
	for _, suffix := range []string{`,"stream_options":{"include_usage":false}`, ""} {
		calls := 0
		client.Transport = standardCaptureTransport(func(r *http.Request) (*http.Response, error) {
			calls++
			if r.URL.String() != "https://api.openai.com/v1/chat/completions" {
				return nil, fmt.Errorf("blocked unexpected destination")
			}
			bytes, err := io.ReadAll(r.Body)
			require.NoError(t, err)
			var body struct {
				StreamOptions struct {
					IncludeUsage bool `json:"include_usage"`
				} `json:"stream_options"`
			}
			require.NoError(t, common.Unmarshal(bytes, &body))
			require.True(t, body.StreamOptions.IncludeUsage)
			// A deliberately missing usage event stops before settlement. This transport
			// never delegates to another transport and cannot open a network socket.
			return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": {"text/event-stream"}}, Body: io.NopCloser(strings.NewReader("data: {\"choices\":[],\"usage\":null}\n\ndata: [DONE]\n\n")), Request: r}, nil
		})
		raw := `{"model":"gpt-6-luna","messages":[{"role":"user","content":"fixture"}],"stream":true` + suffix + `}`
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("POST", "/v1/chat/completions", strings.NewReader(raw))
		c.Request.Header.Set("Content-Type", "application/json")
		common.SetContextKey(c, constant.ContextKeyChannelType, constant.ChannelTypeOpenAI)
		common.SetContextKey(c, constant.ContextKeyChannelId, 1)
		common.SetContextKey(c, constant.ContextKeyChannelBaseUrl, "https://api.openai.com")
		common.SetContextKey(c, constant.ContextKeyOriginalModel, "gpt-6-luna")
		common.SetContextKey(c, constant.ContextKeyChannelKey, "synthetic-only-key")
		var request dto.GeneralOpenAIRequest
		require.NoError(t, common.Unmarshal([]byte(raw), &request))
		info := &relaycommon.RelayInfo{Request: &request, OriginModelName: "gpt-6-luna", RelayFormat: types.RelayFormatOpenAI, RelayMode: relayconstant.RelayModeChatCompletions, RequestURLPath: "/v1/chat/completions", StartTime: time.Now(), IsStream: true, DisablePing: true}
		info.InitChannelMeta(c)
		_, err := service.OpenAIStandardPriceData(info, 10, &types.TokenCountMeta{MaxTokens: 5}, types.GroupRatioInfo{GroupRatio: 1})
		require.NoError(t, err)
		relayErr := TextHelper(c, info)
		require.NotNil(t, relayErr)
		require.Equal(t, service.OpenAIStandardUsageErrorCode, relayErr.GetErrorCode())
		require.Equal(t, 1, calls)
		require.Equal(t, suffix == "", info.ShouldIncludeUsage)
	}
}
